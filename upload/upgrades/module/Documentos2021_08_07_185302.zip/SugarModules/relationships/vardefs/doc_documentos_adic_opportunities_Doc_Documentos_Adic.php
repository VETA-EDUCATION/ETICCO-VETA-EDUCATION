<?php
// created: 2021-08-07 18:53:01
$dictionary["Doc_Documentos_Adic"]["fields"]["doc_documentos_adic_opportunities"] = array (
  'name' => 'doc_documentos_adic_opportunities',
  'type' => 'link',
  'relationship' => 'doc_documentos_adic_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_DOC_DOCUMENTOS_ADIC_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
