<?php
 // created: 2018-02-16 14:47:36
$dictionary['Prospect']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>