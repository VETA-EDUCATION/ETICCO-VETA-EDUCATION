<?php
 // created: 2019-06-26 15:52:49
$dictionary['Campaign']['fields']['origen_c']['inline_edit']='';
$dictionary['Campaign']['fields']['origen_c']['labelValue']='Canal';

 ?>