<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Facebook' => 'Facebook',
  'Mercado_Institucional' => 'Mercado Institucional',
  'Mercado_Natural' => 'Mercado Natural',
  'Pagina_Web' => 'Pagina Web',
  'Referido_Australia' => 'Referido Australia',
  'Referido_Colombia' => 'Referido Colombia',
  'Seminarios' => 'Seminarios',
  'TypeForms' => 'Type Forms',
  'ClienGo' => 'ClienGo',
  'WhatsApp' => 'WhatsApp',
  'EventBrite' => 'Event Brite',
);