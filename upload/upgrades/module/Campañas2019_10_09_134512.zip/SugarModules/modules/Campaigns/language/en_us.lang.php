<?php 
 // created: 2019-10-09 13:45:11
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_CONTACTS'] = 'Students';
$mod_strings['LBL_CAMPAIGN_LEAD_SUBPANEL_TITLE'] = 'Leads';
$mod_strings['LBL_LOG_ENTRIES_CONTACT_TITLE'] = 'Students Created';

?>
