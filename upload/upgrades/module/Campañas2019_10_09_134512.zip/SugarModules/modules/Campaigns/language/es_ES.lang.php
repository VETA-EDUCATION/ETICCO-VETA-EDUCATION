<?php 
 // created: 2019-10-09 13:45:11
$mod_strings['LBL_LEADS'] = 'Prospectos';
$mod_strings['LBL_CAMPAIGN_LEAD_SUBPANEL_TITLE'] = 'Prospectos';
$mod_strings['LBL_CONTACTS'] = 'Estudiantes';
$mod_strings['LBL_LOG_ENTRIES_CONTACT_TITLE'] = 'Estudiantes Creados';
$mod_strings['LBL_ORIGEN'] = 'Canal';

?>
