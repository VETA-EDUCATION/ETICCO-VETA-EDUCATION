<?php
$module_name = 'Veta_Visa';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'FECHA_AVAC' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_AVAC',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_EXAMENES_MEDICOS' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_EXAMENES_MEDICOS',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_FIRMA_ACTA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_FIRMA_ACTA',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_EXPIRACION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_EXPIRACION',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_OTORGADA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_OTORGADA',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_PAGO' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_PAGO',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_APLICACION' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_APLICACION',
    'width' => '10%',
    'default' => true,
  ),
  'ESTADO' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_ESTADO',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'VETA_VISA_OPPORTUNITIES_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_VISA_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
    'id' => 'VETA_VISA_OPPORTUNITIESOPPORTUNITIES_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'VETA_VISA_VETA_COE_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_VISA_VETA_COE_FROM_VETA_COE_TITLE',
    'id' => 'VETA_VISA_VETA_COEVETA_COE_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
);
;
?>
