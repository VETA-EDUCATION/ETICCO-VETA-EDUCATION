<?php
$popupMeta = array (
    'moduleMain' => 'Veta_Liquidacion',
    'varName' => 'Veta_Liquidacion',
    'orderBy' => 'veta_liquidacion.name',
    'whereClauses' => array (
  'name' => 'veta_liquidacion.name',
  'veta_liquidacion_opportunities_name' => 'veta_liquidacion.veta_liquidacion_opportunities_name',
  'assigned_user_id' => 'veta_liquidacion.assigned_user_id',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'veta_liquidacion_opportunities_name',
  5 => 'assigned_user_id',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'veta_liquidacion_opportunities_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_LIQUIDACION_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
    'id' => 'VETA_LIQUIDACION_OPPORTUNITIESOPPORTUNITIES_IDA',
    'width' => '10%',
    'name' => 'veta_liquidacion_opportunities_name',
  ),
  'assigned_user_id' => 
  array (
    'name' => 'assigned_user_id',
    'label' => 'LBL_ASSIGNED_TO',
    'type' => 'enum',
    'function' => 
    array (
      'name' => 'get_user_array',
      'params' => 
      array (
        0 => false,
      ),
    ),
    'width' => '10%',
  ),
),
);
