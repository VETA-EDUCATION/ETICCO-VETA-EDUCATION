<?php
$listViewDefs ['Leads'] = 
array (
  'FULL_NAME' => 
  array (
    'type' => 'fullname',
    'studio' => 
    array (
      'listview' => false,
    ),
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'orderBy' => 'name',
    'default' => true,
    'related_fields' => 
    array (
      0 => 'first_name',
      1 => 'last_name',
      2 => 'salutation',
    ),
  ),
  'PASAPORTE_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_PASAPORTE',
    'width' => '10%',
  ),
  'STATUS' => 
  array (
    'width' => '7%',
    'label' => 'LBL_LIST_STATUS',
    'default' => true,
  ),
  'PHONE_HOME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_HOME_PHONE',
    'default' => true,
  ),
  'PHONE_MOBILE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_MOBILE_PHONE',
    'default' => true,
  ),
  'EMAIL1' => 
  array (
    'width' => '16%',
    'label' => 'LBL_LIST_EMAIL_ADDRESS',
    'sortable' => false,
    'customCode' => '{$EMAIL1_LINK}{$EMAIL1}</a>',
    'default' => true,
  ),
  'EDAD_C' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_EDAD',
    'width' => '10%',
  ),
  'CIUDAD_C' => 
  array (
    'type' => 'dynamicenum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_CIUDAD',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'FECHA_EXPIRACION_VISA_C' => 
  array (
    'type' => 'datetimecombo',
    'default' => true,
    'label' => 'LBL_FECHA_EXPIRACION_VISA',
    'width' => '10%',
  ),
  'OK_COMERCIAL_C' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_OK_COMERCIAL',
    'width' => '10%',
  ),
  'OK_VISAS_C' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_OK_VISAS',
    'width' => '10%',
  ),
  'FECHA_PROXIMO_CONTACTO_C' => 
  array (
    'type' => 'date',
    'default' => true,
    'label' => 'LBL_FECHA_PROXIMO_CONTACTO',
    'width' => '10%',
  ),
  'FECHA_ULTIMO_CONTACTO_C' => 
  array (
    'type' => 'date',
    'default' => true,
    'label' => 'LBL_FECHA_ULTIMO_CONTACTO',
    'width' => '10%',
  ),
  'LEAD_SOURCE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LEAD_SOURCE',
    'default' => true,
  ),
  'ANOS_SIN_ESTUDIAR_C' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_ANOS_SIN_ESTUDIAR',
    'width' => '10%',
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
  ),
  'CONVERTED' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_CONVERTED',
    'width' => '10%',
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'LAST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'FIRST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIRST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_MODIFIED',
    'default' => false,
  ),
  'BIRTHDATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_BIRTHDATE',
    'width' => '10%',
    'default' => false,
  ),
  'HIJOS_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_HIJOS',
    'width' => '10%',
  ),
  'OCUPACION_CONYUGE_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_OCUPACION_CONYUGE',
    'width' => '10%',
  ),
  'EDAD_CONYUGE_C' => 
  array (
    'type' => 'int',
    'default' => false,
    'label' => 'LBL_EDAD_CONYUGE',
    'width' => '10%',
  ),
  'FECHA_VIAJE_C' => 
  array (
    'type' => 'date',
    'default' => false,
    'label' => 'LBL_FECHA_VIAJE',
    'width' => '10%',
  ),
  'NOMBRE_CONYUGE_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_NOMBRE_CONYUGE',
    'width' => '10%',
  ),
  'NACIMIENTO_CONYUGE_C' => 
  array (
    'type' => 'date',
    'default' => false,
    'label' => 'LBL_NACIMIENTO_CONYUGE',
    'width' => '10%',
  ),
  'CARGO_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_CARGO',
    'width' => '10%',
  ),
  'CAMPANA_C' => 
  array (
    'type' => 'relate',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_CAMPANA',
    'id' => 'CAMPAIGN_ID_C',
    'link' => true,
    'width' => '10%',
  ),
  'PRESUPUESTO_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_PRESUPUESTO',
    'currency_format' => true,
    'width' => '10%',
  ),
  'PAIS_C' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_PAIS',
    'width' => '10%',
  ),
  'DEPARTAMENTO_C' => 
  array (
    'type' => 'dynamicenum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_DEPARTAMENTO',
    'width' => '10%',
  ),
  'FECHA_COTIZACION_C' => 
  array (
    'type' => 'date',
    'default' => false,
    'label' => 'LBL_FECHA_COTIZACION',
    'width' => '10%',
  ),
);
?>
