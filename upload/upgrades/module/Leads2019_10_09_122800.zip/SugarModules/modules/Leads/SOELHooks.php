<?php

include_once('modules/ACLRoles/ACLRole.php');
include_once('modules/Campaigns/Campaign.php');

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class SOELHooks {

    function __construct() {

    }

    function establecer_dpto_pais(&$bean, $event, $arguments) {

        //$bean->fecha_expiracion_visa_c = $bean->fecha_expiracion_visa_c == '' ? null : $bean->fecha_expiracion_visa_c;
        
        if( !empty($bean->ciudad_c) && empty($bean->departamento_c)) {

            if( count(explode('/', $bean->ciudad_c)) == 2 )
                $this->establecer_dpto_pais_event_brite($bean);
            else {

                $dpto = $this->obtener_clave_ddl($bean->ciudad_c, 'departamentos_list');

                if(!empty($dpto)) {

                    $bean->departamento_c = $dpto;
                    $pais =  $this->obtener_clave_ddl($bean->ciudad_c, 'pais_list');

                    if(!empty($pais)) {
                        $bean->pais_c = $pais;
                    }
                }
            }

        }

        $l = new Lead();
        $l->retrieve($bean->id);

        // Todo: Usar el ID de campaña
        if(isset($bean->campaign_id_c) and ! isset($l->id)) {

            $c = new Campaign();
            $c->retrieve( $bean->campaign_id_c );

            $bean->lead_source = $c->origen_c;

            // Todo: Asignar el comercial
            $bean->assigned_user_id = $this->obtener_comercial($bean, $c);
            $bean->status = 'Asignado';
        }

    }

    private function obtener_comercial_aleatorio ( $bean, $list ) {

        $uid = null;
        $lista = array();
        $q = "select distinct  related_id 
              from prospect_lists_prospects 
              inner join users on users.id = prospect_lists_prospects.related_id and prospect_lists_prospects.deleted = 0
              where related_type = 'Users' and prospect_list_id = '" . $list->id .  "' and users.status= 'Active' and users.deleted = 0";

        $res = $bean->db->query( $q , true , "Error obteniendo el usuario : " );

        while($row = $bean->db->fetchByAssoc($res))
                array_push($lista, $row['related_id']) ;

        $uid = $lista[random_int (0, count($lista)-1)];
        return $uid;
    }

    private function estan_asignados_todos_los_comerciales($bean, $list) {

        $estan = false;
        $cant1 = $this->obtener_cantidad_comerciales_asignados($bean, $list);
        $cant2 = $this->obtener_cantidad_comerciales_lista($bean, $list);

        if($cant1 == $cant2)
            $estan = true;

        return $estan;
    }

    private function  obtener_cantidad_comerciales_asignados($bean, $list) {

        $cantidad = 0;

        $q = "select count(assigned_user_id) as cantidad 
              from leads 
              where  deleted =0 and status <> 'Converted' and assigned_user_id in 
              (
                  select related_id 
                  from prospect_lists_prospects 
                  inner join users on users.id = prospect_lists_prospects.related_id and prospect_lists_prospects.deleted = 0
                  where related_type = 'Users' and prospect_list_id = '" . $list->id . "' and users.status= 'Active' and users.deleted = 0
              ) ";

        $res = $bean->db->query( $q , true , "Error obteniendo el usuario : " );

        while($row = $bean->db->fetchByAssoc($res))
            $cantidad = $row['cantidad'];

        return $cantidad;
    }

    private function obtener_cantidad_comerciales_lista($bean, $list) {

        $cantidad = 0;

        $q = "select count(related_id) as cantidad  
              from prospect_lists_prospects 
              inner join users on users.id = prospect_lists_prospects.related_id and prospect_lists_prospects.deleted = 0
              where related_type = 'Users' and prospect_list_id = '" . $list->id .  "' and users.status= 'Active' and users.deleted = 0";

        $res = $bean->db->query( $q , true , "Error obteniendo el usuario : " );

        while($row = $bean->db->fetchByAssoc($res))
            $cantidad = $row['cantidad'];

      return $cantidad;
    }

    private function obtener_ultimo_comercial( $bean, $list) {

        $uid = null;

        if( $this->estan_asignados_todos_los_comerciales($bean, $list))    {
            
            $q = "select max(date_entered) as fecha, assigned_user_id 
              from leads 
              where  deleted =0 and status <> 'Converted' and assigned_user_id in 
              (
                  select related_id 
                  from prospect_lists_prospects 
                  inner join users on users.id = prospect_lists_prospects.related_id and prospect_lists_prospects.deleted = 0
                  where related_type = 'Users' and prospect_list_id = '" . $list->id . "' and users.status= 'Active' and users.deleted = 0
              ) 
              group by assigned_user_id
              order by fecha asc limit 1";

            $res = $bean->db->query( $q , true , "Error obteniendo el usuario : " );


            while($row = $bean->db->fetchByAssoc($res))
                $uid = $row['assigned_user_id'];
        }

        return $uid;
    }

    private function obtener_comercial( $bean, $campaign ) {

        $uid = $bean->assigned_user_id;
        $campaign->load_relationship('prospectlists');

        $target_lists = $campaign->prospectlists->getBeans();

        if(count($target_lists) > 0 ) {

            foreach ( $target_lists as $list ) {

                if($list->list_type == 'Comerciales')
                {
                    $uid = $this->obtener_ultimo_comercial($bean, $list);

                    if($uid == null)
                        $uid = $this->obtener_comercial_aleatorio($bean, $list);
                }
            }
        }

        if( $uid == null)
            $uid =  $bean->assigned_user_id;

        return $uid;
    }

    private function establecer_dpto_pais_event_brite($bean)
    {
        $list = explode('/', $bean->ciudad_c);
        $pais = $list[0];
        $ciudad = $list[1];

        global $app_list_strings;

        foreach( $app_list_strings['ciudades_list'] as $clave => $valor ) {

            // Si la ciudad comienza con el pais
            if( $this->startsWith($clave, $pais)) {
                $bean->pais_c = $pais;

                // Si la ciudad termina con la ciudad
                if( $this->endsWith($clave, $ciudad)) {
                    $bean->ciudad_c = $clave;

                    $parts = explode('_', $clave);
                    $bean->departamento_c = $parts[0] . '_' . $parts[1];
                }
            }
        }
    }

    private function startsWith($cadena, $valor)
    {
        $length = strlen($valor);
        return (substr($cadena, 0, $length) === $valor);
    }

    private function endsWith($cadena, $valor)
    {
        $length = strlen($valor);
        if ($length == 0) {
            return true;
        }

        return (substr($cadena, -$length) === $valor);
    }

    private function obtener_clave_ddl($cad, $list)
    {
        $clave = null;
        global $app_list_strings;
        $keys = explode('_',$cad);
        $key = null;

        for( $i = 0 ; $i < count($keys); $i++)
        {
            $key .= $keys[$i];
            $val = $app_list_strings[$list][$key];

            if(!empty($val))
            {
                $clave = $key;
                break;
            }
            else
            {
                $key .= '_';
            }
        }

        return $clave;
    }








}