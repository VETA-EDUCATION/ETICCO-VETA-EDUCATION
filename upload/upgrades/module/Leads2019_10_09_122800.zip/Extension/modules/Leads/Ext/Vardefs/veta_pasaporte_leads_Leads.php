<?php
// created: 2018-07-30 11:24:33
$dictionary["Lead"]["fields"]["veta_pasaporte_leads"] = array (
  'name' => 'veta_pasaporte_leads',
  'type' => 'link',
  'relationship' => 'veta_pasaporte_leads',
  'source' => 'non-db',
  'module' => 'Veta_Pasaporte',
  'bean_name' => 'Veta_Pasaporte',
  'side' => 'right',
  'vname' => 'LBL_VETA_PASAPORTE_LEADS_FROM_VETA_PASAPORTE_TITLE',
);
