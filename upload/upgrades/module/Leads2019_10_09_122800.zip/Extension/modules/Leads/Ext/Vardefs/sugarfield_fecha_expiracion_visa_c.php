<?php
 // created: 2019-09-26 15:01:52
$dictionary['Lead']['fields']['fecha_expiracion_visa_c']['inline_edit']='';
$dictionary['Lead']['fields']['fecha_expiracion_visa_c']['options']='date_range_search_dom';
$dictionary['Lead']['fields']['fecha_expiracion_visa_c']['labelValue']='Fecha Expiracion Visa';
$dictionary['Lead']['fields']['fecha_expiracion_visa_c']['enable_range_search']='1';

 ?>