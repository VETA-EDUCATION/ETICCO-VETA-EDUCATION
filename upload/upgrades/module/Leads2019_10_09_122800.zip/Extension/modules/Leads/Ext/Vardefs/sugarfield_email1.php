<?php
 // created: 2018-02-17 17:00:44
$dictionary['Lead']['fields']['email1']['inline_edit']='';
$dictionary['Lead']['fields']['email1']['merge_filter']='disabled';

 ?>