<?php
 // created: 2018-02-17 18:44:43
$dictionary['Lead']['fields']['lead_source']['inline_edit']='';
$dictionary['Lead']['fields']['lead_source']['comments']='';
$dictionary['Lead']['fields']['lead_source']['merge_filter']='disabled';

 ?>