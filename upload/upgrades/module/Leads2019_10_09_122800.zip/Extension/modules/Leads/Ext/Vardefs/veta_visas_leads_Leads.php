<?php
// created: 2018-07-30 11:24:34
$dictionary["Lead"]["fields"]["veta_visas_leads"] = array (
  'name' => 'veta_visas_leads',
  'type' => 'link',
  'relationship' => 'veta_visas_leads',
  'source' => 'non-db',
  'module' => 'Veta_Visas',
  'bean_name' => 'Veta_Visas',
  'side' => 'right',
  'vname' => 'LBL_VETA_VISAS_LEADS_FROM_VETA_VISAS_TITLE',
);
