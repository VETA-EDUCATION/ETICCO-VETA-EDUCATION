<?php
 // created: 2018-02-17 17:01:37
$dictionary['Lead']['fields']['status_description']['inline_edit']='';
$dictionary['Lead']['fields']['status_description']['comments']='Description of the status of the lead';
$dictionary['Lead']['fields']['status_description']['merge_filter']='disabled';
$dictionary['Lead']['fields']['status_description']['rows']='4';
$dictionary['Lead']['fields']['status_description']['cols']='20';

 ?>