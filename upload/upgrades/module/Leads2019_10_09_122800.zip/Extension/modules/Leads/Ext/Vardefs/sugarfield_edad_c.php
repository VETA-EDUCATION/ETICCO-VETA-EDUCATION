<?php
 // created: 2019-08-20 20:56:26
$dictionary['Lead']['fields']['edad_c']['inline_edit']='';
$dictionary['Lead']['fields']['edad_c']['labelValue']='Edad';

 ?>