<?php
 // created: 2018-02-16 14:53:01
$dictionary['Lead']['fields']['anos_sin_estudiar_c']['inline_edit']='';
$dictionary['Lead']['fields']['anos_sin_estudiar_c']['options']='numeric_range_search_dom';
$dictionary['Lead']['fields']['anos_sin_estudiar_c']['labelValue']='Años sin estudiar';
$dictionary['Lead']['fields']['anos_sin_estudiar_c']['enable_range_search']='1';

 ?>