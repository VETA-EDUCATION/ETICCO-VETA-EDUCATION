<?php
 // created: 2018-02-17 17:00:51
$dictionary['Lead']['fields']['first_name']['inline_edit']='';
$dictionary['Lead']['fields']['first_name']['comments']='First name of the contact';
$dictionary['Lead']['fields']['first_name']['merge_filter']='disabled';

 ?>