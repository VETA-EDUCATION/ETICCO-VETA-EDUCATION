<?php
 // created: 2018-02-16 15:14:20
$dictionary['Lead']['fields']['ok_comercial_c']['inline_edit']='';
$dictionary['Lead']['fields']['ok_comercial_c']['labelValue']='Visto Bueno Comercial';

 ?>