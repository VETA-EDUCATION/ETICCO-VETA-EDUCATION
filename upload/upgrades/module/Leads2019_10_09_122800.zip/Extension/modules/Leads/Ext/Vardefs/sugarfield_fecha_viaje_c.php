<?php
 // created: 2018-02-16 15:10:46
$dictionary['Lead']['fields']['fecha_viaje_c']['inline_edit']='';
$dictionary['Lead']['fields']['fecha_viaje_c']['labelValue']='Fecha Viaje';

 ?>