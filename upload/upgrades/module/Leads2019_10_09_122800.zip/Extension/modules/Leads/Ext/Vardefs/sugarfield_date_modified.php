<?php
 // created: 2019-09-18 10:08:08
$dictionary['Lead']['fields']['date_modified']['audited']=true;
$dictionary['Lead']['fields']['date_modified']['comments']='Date record last modified';
$dictionary['Lead']['fields']['date_modified']['merge_filter']='disabled';

 ?>