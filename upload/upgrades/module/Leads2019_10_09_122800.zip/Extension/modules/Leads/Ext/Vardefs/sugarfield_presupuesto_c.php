<?php
 // created: 2018-02-16 15:16:35
$dictionary['Lead']['fields']['presupuesto_c']['inline_edit']='';
$dictionary['Lead']['fields']['presupuesto_c']['labelValue']='Presupuesto';

 ?>