<?php
 // created: 2018-02-17 17:00:58
$dictionary['Lead']['fields']['last_name']['inline_edit']='';
$dictionary['Lead']['fields']['last_name']['comments']='Last name of the contact';
$dictionary['Lead']['fields']['last_name']['merge_filter']='disabled';

 ?>