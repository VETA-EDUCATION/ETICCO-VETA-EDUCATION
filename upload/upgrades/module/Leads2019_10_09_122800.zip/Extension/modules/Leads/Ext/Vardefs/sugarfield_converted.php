<?php
 // created: 2018-02-17 17:00:28
$dictionary['Lead']['fields']['converted']['inline_edit']='';
$dictionary['Lead']['fields']['converted']['comments']='Has Lead been converted to a Contact (and other Sugar objects)';
$dictionary['Lead']['fields']['converted']['merge_filter']='disabled';

 ?>