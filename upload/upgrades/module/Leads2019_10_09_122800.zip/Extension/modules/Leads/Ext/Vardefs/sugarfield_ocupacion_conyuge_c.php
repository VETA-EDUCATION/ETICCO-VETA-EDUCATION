<?php
 // created: 2018-02-16 15:13:32
$dictionary['Lead']['fields']['ocupacion_conyuge_c']['inline_edit']='';
$dictionary['Lead']['fields']['ocupacion_conyuge_c']['labelValue']='Ocupacion Conyuge';

 ?>