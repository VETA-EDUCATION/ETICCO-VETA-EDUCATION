<?php
 // created: 2018-02-16 15:05:36
$dictionary['Lead']['fields']['ciudad_c']['inline_edit']='';
$dictionary['Lead']['fields']['ciudad_c']['labelValue']='Ciudad';

 ?>