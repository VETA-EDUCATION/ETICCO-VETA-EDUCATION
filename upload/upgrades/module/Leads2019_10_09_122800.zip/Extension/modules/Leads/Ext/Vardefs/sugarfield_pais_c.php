<?php
 // created: 2018-02-16 15:03:38
$dictionary['Lead']['fields']['pais_c']['inline_edit']='';
$dictionary['Lead']['fields']['pais_c']['labelValue']='Pais';

 ?>