<?php
 // created: 2018-02-16 15:04:35
$dictionary['Lead']['fields']['departamento_c']['inline_edit']='';
$dictionary['Lead']['fields']['departamento_c']['labelValue']='Departamento';

 ?>