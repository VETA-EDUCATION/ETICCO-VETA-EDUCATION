<?php
 // created: 2018-02-16 15:08:56
$dictionary['Lead']['fields']['fecha_proximo_contacto_c']['inline_edit']='';
$dictionary['Lead']['fields']['fecha_proximo_contacto_c']['labelValue']='Fecha Proximo Contacto';

 ?>