<?php
 // created: 2018-02-16 14:54:53
$dictionary['Lead']['fields']['cargo_c']['inline_edit']='';
$dictionary['Lead']['fields']['cargo_c']['labelValue']='Cargo Actual';

 ?>