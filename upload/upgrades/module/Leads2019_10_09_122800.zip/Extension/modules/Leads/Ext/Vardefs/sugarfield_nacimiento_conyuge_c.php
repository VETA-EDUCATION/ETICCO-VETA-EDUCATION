<?php
 // created: 2018-02-16 15:12:07
$dictionary['Lead']['fields']['nacimiento_conyuge_c']['inline_edit']='';
$dictionary['Lead']['fields']['nacimiento_conyuge_c']['labelValue']='Fecha de Nacimiento Conyuge';

 ?>