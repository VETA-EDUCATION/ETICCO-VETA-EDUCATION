<?php
 // created: 2018-02-17 17:00:17
$dictionary['Lead']['fields']['birthdate']['inline_edit']='';
$dictionary['Lead']['fields']['birthdate']['comments']='The birthdate of the contact';
$dictionary['Lead']['fields']['birthdate']['merge_filter']='disabled';
$dictionary['Lead']['fields']['birthdate']['enable_range_search']=false;

 ?>