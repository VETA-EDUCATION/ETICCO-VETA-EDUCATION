<?php
 // created: 2019-09-18 10:10:41
$dictionary['Lead']['fields']['campana_c']['inline_edit']='';
$dictionary['Lead']['fields']['campana_c']['labelValue']='Campaign';

 ?>