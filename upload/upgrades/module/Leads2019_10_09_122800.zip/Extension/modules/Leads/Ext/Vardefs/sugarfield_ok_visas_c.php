<?php
 // created: 2018-02-16 15:15:07
$dictionary['Lead']['fields']['ok_visas_c']['inline_edit']='';
$dictionary['Lead']['fields']['ok_visas_c']['labelValue']='Visto Bueno Visas';

 ?>