<?php
 // created: 2018-02-16 15:15:45
$dictionary['Lead']['fields']['pasaporte_c']['inline_edit']='';
$dictionary['Lead']['fields']['pasaporte_c']['labelValue']='Pasaporte';

 ?>