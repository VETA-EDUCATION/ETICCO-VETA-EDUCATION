<?php
 // created: 2018-02-17 17:01:29
$dictionary['Lead']['fields']['status']['inline_edit']='';
$dictionary['Lead']['fields']['status']['comments']='Status of the lead';
$dictionary['Lead']['fields']['status']['merge_filter']='disabled';

 ?>