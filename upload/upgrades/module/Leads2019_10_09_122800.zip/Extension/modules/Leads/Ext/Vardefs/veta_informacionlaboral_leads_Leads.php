<?php
// created: 2018-07-30 11:24:35
$dictionary["Lead"]["fields"]["veta_informacionlaboral_leads"] = array (
  'name' => 'veta_informacionlaboral_leads',
  'type' => 'link',
  'relationship' => 'veta_informacionlaboral_leads',
  'source' => 'non-db',
  'module' => 'Veta_InformacionLaboral',
  'bean_name' => 'Veta_InformacionLaboral',
  'side' => 'right',
  'vname' => 'LBL_VETA_INFORMACIONLABORAL_LEADS_FROM_VETA_INFORMACIONLABORAL_TITLE',
);
