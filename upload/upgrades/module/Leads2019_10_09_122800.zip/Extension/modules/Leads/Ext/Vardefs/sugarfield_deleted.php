<?php
 // created: 2018-02-17 17:00:35
$dictionary['Lead']['fields']['deleted']['inline_edit']='';
$dictionary['Lead']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Lead']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Lead']['fields']['deleted']['reportable']=true;

 ?>