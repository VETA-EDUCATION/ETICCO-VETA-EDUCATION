<?php
 // created: 2018-02-16 15:08:10
$dictionary['Lead']['fields']['fecha_cotizacion_c']['inline_edit']='';
$dictionary['Lead']['fields']['fecha_cotizacion_c']['labelValue']='Fecha Cotizacion';

 ?>