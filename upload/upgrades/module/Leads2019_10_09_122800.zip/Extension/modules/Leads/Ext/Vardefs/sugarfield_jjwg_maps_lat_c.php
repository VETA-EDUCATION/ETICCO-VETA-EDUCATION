<?php
 // created: 2018-02-16 14:47:35
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>