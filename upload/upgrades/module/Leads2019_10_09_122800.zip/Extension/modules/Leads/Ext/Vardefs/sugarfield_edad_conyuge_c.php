<?php
 // created: 2018-02-16 15:07:16
$dictionary['Lead']['fields']['edad_conyuge_c']['inline_edit']='';
$dictionary['Lead']['fields']['edad_conyuge_c']['labelValue']='Edad Conyuge';

 ?>