<?php
 // created: 2018-02-16 15:12:44
$dictionary['Lead']['fields']['nombre_conyuge_c']['inline_edit']='';
$dictionary['Lead']['fields']['nombre_conyuge_c']['labelValue']='Nombre Conyuge';

 ?>