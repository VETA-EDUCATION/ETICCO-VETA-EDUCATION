<?php
 // created: 2018-02-17 17:01:46
$dictionary['Lead']['fields']['title']['inline_edit']='';
$dictionary['Lead']['fields']['title']['comments']='The title of the contact';
$dictionary['Lead']['fields']['title']['merge_filter']='disabled';

 ?>