<?php
 // created: 2018-02-16 15:09:38
$dictionary['Lead']['fields']['fecha_ultimo_contacto_c']['inline_edit']='';
$dictionary['Lead']['fields']['fecha_ultimo_contacto_c']['labelValue']='Fecha Ultimo Contacto';

 ?>