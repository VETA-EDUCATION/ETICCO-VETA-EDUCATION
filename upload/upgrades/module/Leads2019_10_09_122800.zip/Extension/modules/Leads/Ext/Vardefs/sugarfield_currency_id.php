<?php
 // created: 2018-02-16 15:16:35
$dictionary['Lead']['fields']['currency_id']['inline_edit']=1;

 ?>