<?php
 // created: 2019-07-15 15:38:11
$dictionary['Lead']['fields']['hijos_c']['inline_edit']='';
$dictionary['Lead']['fields']['hijos_c']['labelValue']='Fecha 2 de Viaje';

 ?>