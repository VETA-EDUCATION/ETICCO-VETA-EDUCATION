<?php
 // created: 2018-02-16 14:54:04
$dictionary['Lead']['fields']['campaign_id_c']['inline_edit']=1;

 ?>