<?php
// created: 2021-09-02 13:15:24
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_notes"] = array (
  'name' => 'veta_coe_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
