<?php
// created: 2021-09-02 13:15:24
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_calls"] = array (
  'name' => 'veta_coe_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
