<?php
// created: 2021-09-02 13:15:21
$dictionary["Task"]["fields"]["veta_liquidacion_activities_tasks"] = array (
  'name' => 'veta_liquidacion_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_tasks',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_TASKS_FROM_VETA_LIQUIDACION_TITLE',
);
