<?php
// created: 2021-09-02 13:15:24
$dictionary["Veta_Recibo"]["fields"]["veta_detallerecibo_veta_recibo"] = array (
  'name' => 'veta_detallerecibo_veta_recibo',
  'type' => 'link',
  'relationship' => 'veta_detallerecibo_veta_recibo',
  'source' => 'non-db',
  'module' => 'Veta_DetalleRecibo',
  'bean_name' => 'Veta_DetalleRecibo',
  'side' => 'right',
  'vname' => 'LBL_VETA_DETALLERECIBO_VETA_RECIBO_FROM_VETA_DETALLERECIBO_TITLE',
);
