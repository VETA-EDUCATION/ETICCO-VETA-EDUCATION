<?php
// created: 2021-09-02 13:15:21
$dictionary["Call"]["fields"]["veta_aplicacion_activities_calls"] = array (
  'name' => 'veta_aplicacion_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_CALLS_FROM_VETA_APLICACION_TITLE',
);
