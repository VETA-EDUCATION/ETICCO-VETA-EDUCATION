<?php
// created: 2021-09-02 13:15:25
$dictionary["Contact"]["fields"]["veta_requerimiento_contacts"] = array (
  'name' => 'veta_requerimiento_contacts',
  'type' => 'link',
  'relationship' => 'veta_requerimiento_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Requerimiento',
  'bean_name' => 'Veta_Requerimiento',
  'side' => 'right',
  'vname' => 'LBL_VETA_REQUERIMIENTO_CONTACTS_FROM_VETA_REQUERIMIENTO_TITLE',
);
