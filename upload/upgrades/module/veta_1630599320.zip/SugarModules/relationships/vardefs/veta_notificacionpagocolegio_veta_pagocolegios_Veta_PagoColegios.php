<?php
// created: 2021-09-02 13:15:20
$dictionary["Veta_PagoColegios"]["fields"]["veta_notificacionpagocolegio_veta_pagocolegios"] = array (
  'name' => 'veta_notificacionpagocolegio_veta_pagocolegios',
  'type' => 'link',
  'relationship' => 'veta_notificacionpagocolegio_veta_pagocolegios',
  'source' => 'non-db',
  'module' => 'Veta_NotificacionPagoColegio',
  'bean_name' => 'Veta_NotificacionPagoColegio',
  'side' => 'right',
  'vname' => 'LBL_VETA_NOTIFICACIONPAGOCOLEGIO_VETA_PAGOCOLEGIOS_FROM_VETA_NOTIFICACIONPAGOCOLEGIO_TITLE',
);
