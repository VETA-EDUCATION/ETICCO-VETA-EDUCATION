<?php
// created: 2021-09-02 13:15:21
$dictionary["Email"]["fields"]["veta_liquidacion_activities_emails"] = array (
  'name' => 'veta_liquidacion_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_EMAILS_FROM_VETA_LIQUIDACION_TITLE',
);
