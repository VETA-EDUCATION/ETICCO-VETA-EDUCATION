<?php
// created: 2021-09-02 13:15:22
$dictionary["Veta_Loo"]["fields"]["veta_loo_cases"] = array (
  'name' => 'veta_loo_cases',
  'type' => 'link',
  'relationship' => 'veta_loo_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_LOO_CASES_FROM_CASES_TITLE',
);
