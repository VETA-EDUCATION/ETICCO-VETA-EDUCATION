<?php
// created: 2021-09-02 13:15:23
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_emails"] = array (
  'name' => 'veta_visa_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
