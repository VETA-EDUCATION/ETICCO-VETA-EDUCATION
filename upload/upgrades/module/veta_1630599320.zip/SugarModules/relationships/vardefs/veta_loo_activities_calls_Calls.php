<?php
// created: 2021-09-02 13:15:22
$dictionary["Call"]["fields"]["veta_loo_activities_calls"] = array (
  'name' => 'veta_loo_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_CALLS_FROM_VETA_LOO_TITLE',
);
