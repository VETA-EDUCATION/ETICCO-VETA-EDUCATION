<?php
// created: 2021-09-02 13:15:24
$dictionary["Meeting"]["fields"]["veta_coe_activities_meetings"] = array (
  'name' => 'veta_coe_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_MEETINGS_FROM_VETA_COE_TITLE',
);
