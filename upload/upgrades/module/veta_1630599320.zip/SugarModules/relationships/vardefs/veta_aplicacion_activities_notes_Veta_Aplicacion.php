<?php
// created: 2021-09-02 13:15:21
$dictionary["Veta_Aplicacion"]["fields"]["veta_aplicacion_activities_notes"] = array (
  'name' => 'veta_aplicacion_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
