<?php
// created: 2021-09-02 13:15:23
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_notes"] = array (
  'name' => 'veta_visa_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
