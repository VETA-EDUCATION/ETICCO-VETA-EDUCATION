<?php
// created: 2021-09-02 13:15:22
$dictionary["Veta_Presupuesto"]["fields"]["veta_detallepresupuesto_veta_presupuesto"] = array (
  'name' => 'veta_detallepresupuesto_veta_presupuesto',
  'type' => 'link',
  'relationship' => 'veta_detallepresupuesto_veta_presupuesto',
  'source' => 'non-db',
  'module' => 'Veta_DetallePresupuesto',
  'bean_name' => 'Veta_DetallePresupuesto',
  'side' => 'right',
  'vname' => 'LBL_VETA_DETALLEPRESUPUESTO_VETA_PRESUPUESTO_FROM_VETA_DETALLEPRESUPUESTO_TITLE',
);
