<?php
// created: 2021-09-02 13:15:23
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_tasks"] = array (
  'name' => 'veta_visa_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
