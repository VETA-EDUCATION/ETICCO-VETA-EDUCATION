<?php
// created: 2021-09-02 13:15:21
$dictionary["Note"]["fields"]["veta_liquidacion_activities_notes"] = array (
  'name' => 'veta_liquidacion_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_NOTES_FROM_VETA_LIQUIDACION_TITLE',
);
