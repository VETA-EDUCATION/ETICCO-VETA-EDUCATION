<?php
// created: 2021-09-02 13:15:23
$dictionary["Lead"]["fields"]["veta_visas_leads"] = array (
  'name' => 'veta_visas_leads',
  'type' => 'link',
  'relationship' => 'veta_visas_leads',
  'source' => 'non-db',
  'module' => 'Veta_Visas',
  'bean_name' => 'Veta_Visas',
  'side' => 'right',
  'vname' => 'LBL_VETA_VISAS_LEADS_FROM_VETA_VISAS_TITLE',
);
