<?php


$dictionary[ 'Veta_Curso' ][ 'fields' ][ 'jornada' ][ 'type' ]    = 'enum';
$dictionary[ 'Veta_Curso' ][ 'fields' ][ 'jornada' ][ 'options' ] = 'jornada_list';
$dictionary[ 'Veta_Curso' ][ 'fields' ][ 'campus' ][ 'type' ]    = 'enum';
$dictionary[ 'Veta_Curso' ][ 'fields' ][ 'campus' ][ 'options' ] = 'ciudades_list';

