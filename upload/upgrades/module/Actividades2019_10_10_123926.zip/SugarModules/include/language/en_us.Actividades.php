<?php 
$app_list_strings['parent_type_display'] = array (
  'Contacts' => 'Student',
  'Veta_Liquidacion' => 'Liquidation',
);$app_list_strings['record_type_display_notes'] = array (
  'Contacts' => 'Student',
  'Veta_Liquidacion' => 'Liquidation',
);