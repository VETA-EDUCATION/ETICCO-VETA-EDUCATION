<?php 
$app_list_strings['parent_type_display'] = array (
  'Leads' => 'Prospecto',
  'Contacts' => 'Estudiante',
  'Veta_Aplicacion' => 'Aplicacion',
  'Veta_COE' => 'COE',
  'Veta_Liquidacion' => 'Liquidacion',
  'Veta_Loo' => 'Carta de Oferta',
  'Veta_PagoColegios' => 'Pago a Colegios',
  'Veta_Visa' => 'Visa',
);$app_list_strings['record_type_display_notes'] = array (
  'Leads' => 'Prospecto',
  'Contacts' => 'Estudiante',
  'Veta_Aplicacion' => 'Aplicacion',
  'Veta_COE' => 'COE',
  'Veta_Liquidacion' => 'Liquidacion',
  'Veta_Loo' => 'Carta de Oferta',
  'Veta_PagoColegios' => 'Pago a Colegios',
  'Veta_Visa' => 'Visa',
);