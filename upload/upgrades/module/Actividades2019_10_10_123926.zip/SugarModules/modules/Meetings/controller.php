<?php
class MeetingsController extends SugarController
{
    function action_msg()
    {
        $this->view = 'msg';
    }

}
?>
