<?php 
 // created: 2019-10-10 12:39:24
$mod_strings['LBL_LEADS'] = 'Prospectos';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Prospectos';
$mod_strings['LBL_LIST_CONTACT'] = 'Estudiante';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Relaciones';
$mod_strings['VETA_APLICACION_ACTIVITIES_MEETINGS_NAME'] = 'Aplicacion';
$mod_strings['VETA_LOO_ACTIVITIES_MEETINGS_NAME'] = 'Carta de Oferta';
$mod_strings['VETA_COE_ACTIVITIES_MEETINGS_NAME'] = 'COE';
$mod_strings['VETA_VISAS_ACTIVITIES_MEETINGS_NAME'] = 'Visa';
$mod_strings['VETA_LIQUIDACION_ACTIVITIES_MEETINGS_NAME'] = 'Liquidacion';
$mod_strings['VETA_PAGOCOLEGIOS_ACTIVITIES_MEETINGS_NAME'] = 'Pago a Colegios';
$mod_strings['LBL_SUBJECT'] = 'Asunto:';
$mod_strings['LBL_STATUS'] = 'Estado:';
$mod_strings['LBL_DATE'] = 'Fecha Inicio:';
$mod_strings['LBL_DELETED'] = 'Borrado';
$mod_strings['LBL_DESCRIPTION'] = 'Descripción:';
$mod_strings['LBL_PARENT_TYPE'] = 'Tipo de Padre';
$mod_strings['LBL_LOCATION'] = 'Lugar:';
$mod_strings['LBL_ESTUDIANTE_CONTACT_ID'] = 'Estudiante (relacionado Estudiante ID)';
$mod_strings['LBL_ESTUDIANTE'] = 'Estudiante';

?>
