<?php

require_once('modules/EmailTemplates/EmailTemplate.php');
require_once('modules/Administration/Administration.php');
require_once('modules/Users/User.php');
require_once('include/phpmailer/class.phpmailer.php');

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class SOELHooks
{

    function __construct()
    {

    }

    function enviar_documentacion_primera_cita(&$bean, $event, $arguments)
    {
        if($this->es_primera_cita($bean))
        {
            $m = new Meeting();
            $m->retrieve($bean->id);

            // Obteniendo el documento cotizacion.pdf
            $docs = $this->obtener_adjuntos($bean);

            if($bean->status == 'Held')
            {
                if( $m->status == 'Held' )
                {
                    header("Location: index.php?action=msg&module=Meetings&number=2");
                    exit;
                }
                else
                {
                    $cotizacion = $this->encontrar_documento('cotizacion.pdf', $docs);
                    $acta = $this->encontrar_documento('acta.pdf', $docs);

                    if( !empty($cotizacion) and !empty($acta) )
                    {
                        $this->enviar_archivos_primera_cita($bean, $cotizacion, $acta);
                    }
                    else
                    {
                        header("Location: index.php?action=msg&module=Meetings&number=1");
                        exit;
                    }
                }
            }
        }

    }

    function actualizar_prospecto(&$bean, $event, $arguments)
    {
        if($bean->parent_type == 'Leads')
        {
            $l = new Lead();
            $l->retrieve($bean->parent_id);

            if(isset($l->id))
            {
                if($bean->status == 'Planned')
                {
                    if($bean->date_start >  $l->fecha_proximo_contacto_c )
                        $l->fecha_proximo_contacto_c =  substr($bean->date_start, 0, 10);
                }
                elseif ($bean->status == 'Held')
                {
                    if($bean->date_start >  $l->fecha_ultimo_contacto_c  )
                        $l->fecha_ultimo_contacto_c  = substr($bean->date_start, 0, 10);
                }

                $l->save(false);
            }
        }
    }

    function establecer_estudiante(&$bean, $event, $arguments)
    {
        $bean->contact_id_c = $this->establecer_estudiante_desde_estudiante($bean);

        if(!isset( $bean->contact_id_c  ) )
            $bean->contact_id_c = $this->establecer_estudiante_desde_parent($bean);
    }

    function enviar_archivos_primera_cita( $cita, $cotizacion, $acta )
    {
        global $sugar_config;

        $prospecto = new Lead();
        $prospecto->retrieve( $cita->parent_id );

        $usuario = new User();
        $usuario->retrieve($cita->assigned_user_id);

        if(empty($prospecto->email1))
        {
            header("Location: index.php?action=msg&module=Meetings&number=3");
            exit;
        }

        $cotizacion_file = "{$sugar_config['upload_dir']}{$cotizacion->id}";
        $acta_file = "{$sugar_config['upload_dir']}{$acta->id}";

        $tEmail = new EmailTemplate();
        $tEmail->retrieve('primera_cita');

        $admin = new Administration();
        $admin->retrieveSettings();
        $mail = new PHPMailer();
        $mail->IsHTML(true);
        $mail->CharSet = 'UTF-8';

        if( $admin->settings['mail_sendtype'] == "SMTP" )
        {
            $mail->IsSMTP();	// set mailer to use SMTP

            $mail->Host = $admin->settings['mail_smtpserver'];
            $mail->Port = $admin->settings['mail_smtpport'];

            if( $admin->settings['mail_smtpauth_req'] )
            {
                $mail->SMTPAuth = TRUE;
                $mail->Username = $admin->settings['mail_smtpuser'];
                $mail->Password = $admin->settings['mail_smtppass'];
            }

            $mail->Mailer = "smtp";
            $mail->SMTPKeepAlive = true;
            $mail->From = $admin->settings['notify_fromaddress'];
            $mail->FromName = $admin->settings['notify_fromname'];

            $mail->Subject = $tEmail->subject;


            $tEmail->body_html = html_entity_decode($tEmail->body_html, ENT_COMPAT | ENT_HTML401,"UTF-8");

            $tEmail->body_html = str_replace("$" . "lead_name", $prospecto->name, $tEmail->body_html);
            $tEmail->body_html = str_replace("$" . "lead_assigned_user_name", $usuario->name, $tEmail->body_html);
            $tEmail->body_html = str_replace("$" . "lead_assigned_phone", $usuario->phone_mobile, $tEmail->body_html);
            $tEmail->body_html = str_replace("$" . "lead_email", $usuario->email1, $tEmail->body_html);

            $mail->Body = $tEmail->body_html;
            $mail->addAttachment( $cotizacion_file,'Cotizacion.pdf' );
            $mail->addAttachment( $acta_file, 'Acta.pdf' );

            if( $admin->settings['mail_smtpssl'] == 1 )
                $mail->SMTPSecure= "ssl"; //  Used instead of TLS when only POP mail is selected

            if( $admin->settings['mail_smtpssl'] == 2 )
                $mail->SMTPSecure= "tls"; //  Used instead of TLS when only POP mail is selected

            $mail->Port = $admin->settings['mail_smtpport']; // Used instead of 587 when only POP mail is selected
            $mail->AddAddress( $prospecto->email1 );
        }
        else
        {
            $mail->mailer = "sendmail";
        }

        //now create email
        if ($mail->Send()) // Si se logra enviar el correo creamos un correo con los adjuntos de cotizacion y acuerdo de servicios y los relacionamos con el prospecto
        {
            $emailObj = new Email();
            $emailObj->to_addrs= '';
            $emailObj->type= 'archived';
            $emailObj->deleted = '0';
            $emailObj->name = $mail->Subject ;
            $emailObj->description = null;
            $emailObj->description_html = $mail->Body;
            $emailObj->from_addr = $mail->From;
            $emailObj->parent_type = $prospecto->module_dir;
            $emailObj->parent_id = $prospecto->id;

            $emailObj->date_sent = TimeDate::getInstance()->nowDb();
            $emailObj->modified_user_id = '1';
            $emailObj->created_by = '1';
            $emailObj->status = 'sent';
            $emailObj->save();

            $note = new Note();
            $note->id = create_guid();
            $note->new_with_id = true; // duplicating the note with files

            $note->parent_id = $emailObj->id;
            $note->parent_type = $emailObj->module_dir;
            $note->name = "Cotizacion.pdf";
            $note->filename = "Cotizacion.pdf";
            $note->file_mime_type = $emailObj->email2GetMime($cotizacion_file);
            $noteFile = "{$sugar_config['upload_dir']}{$note->id}";

            if(!copy($cotizacion_file, $noteFile))
            {
                $GLOBALS['log']->debug("EMAIL 2.0: could not copy attachment file to cache/upload [ {$noteFile} ]");
            }

            $note->save();

            $note2 = new Note();
            $note2->id = create_guid();
            $note2->new_with_id = true; // duplicating the note with files

            $note2->parent_id = $emailObj->id;
            $note2->parent_type = $emailObj->module_dir;
            $note2->name = "Acta.pdf";
            $note2->filename = "Acta.pdf";
            $note2->file_mime_type = $emailObj->email2GetMime($acta_file);
            $noteFile2 = "{$sugar_config['upload_dir']}{$note2->id}";

            if(!copy($acta_file, $noteFile2))
            {
                $GLOBALS['log']->debug("EMAIL 2.0: could not copy attachment file to cache/upload [ {$noteFile2} ]");
            }

            $note2->save();
            /*$prospecto->fecha_cotizacion_c = substr($cita->date_start, 0, 10);
            $prospecto->save(false);*/

            $q = "UPDATE leads_cstm SET fecha_cotizacion_c = '" . substr($cita->date_start, 0, 10) . "' WHERE id_c = '" . $prospecto->id . "'";
            $res = $prospecto->db->query( $q , true , "Error actualizando la fecha de cotizacion : " );
        }
    }

    function obtener_adjuntos($cita)
    {
        $docs = array();

        $q = "SELECT id FROM notes WHERE parent_type = 'Meetings' AND parent_id = '$cita->id' AND deleted = 0 ";
        $res = $cita->db->query( $q , true , "Error obteniendo la primera cita : " );

        while($row = $cita->db->fetchByAssoc($res))
        {
            $nota = new Note();
            $nota->retrieve($row['id']);
            array_push($docs,$nota);
        }

        return $docs;
    }

    function es_primera_cita($cita)
    {
        $es = false;
        $registros = 0;

        if($cita->parent_type == 'Leads')
        {
            $q = "SELECT id FROM meetings WHERE parent_type = 'Leads' AND parent_id = '$cita->parent_id' AND deleted = 0 ORDER BY date_entered ASC LIMIT 1";
            $res = $cita->db->query( $q , true , "Error obteniendo la primera cita : " );

            while($row = $cita->db->fetchByAssoc($res))
            {
                if( $row['id'] == $cita->id)
                    $es = true;

                $registros = 1;
            }

            if($registros == 0)
                $es = true;
        }

        return $es;
    }

    function encontrar_documento($filename, $docs)
    {
        $documento = null;

        foreach($docs as $d)
        {
            if($d->filename == $filename)
                $documento = $d;
        }

        return $documento;
    }

    private function establecer_estudiante_desde_estudiante($bean)
    {
        $cid = null;
        $es = $bean->get_linked_beans('contacts','Contacts');

        foreach( $es as $e )
        {
            $cid = $e->id;
        }

        /*$c = new Contact();
        $c->retrieve($bean->parent_id);

        if(!empty($c->id))
            $cid = $c->id;*/

        /*if(isset($bean->contact_id))
            $cid = $bean->contact_id;*/

        return $cid;
    }

    private function establecer_estudiante_desde_parent($bean)
    {
        $cid = null;

        if(isset($bean->parent_type))
        {
            if($bean->parent_type == "Opportunities")
            {
                $o = new Opportunity();
                $o->retrieve($bean->parent_id);

                $es = $o->get_linked_beans('contacts_opportunities_1','Contacts');

                foreach( $es as $e )
                {
                    $cid = $e->id;
                }
            }
            else
            {
                $b = BeanFactory::getBean($bean->parent_type, $bean->parent_id );
                $cid = $this->establecer_estudiante_desde_parent($b);
            }
        }
        else
        {
            switch (get_class($bean))
            {
                case "Opportunity":
                    $cid = $this->obtener_estudiante_desde_oportunidad($bean);
                    break;
                case "Veta_Aplicacion":
                    $cid = $this->obtener_estudiante_desde_app($bean);
                    break;
                case "Veta_Loo":
                    $cid = $this->obtener_estudiante_desde_loo($bean);
                    break;
                case "Veta_COE":
                    $cid = $this->obtener_estudiante_desde_coe($bean);
                    break;
                case "Veta_LooCorreccion":
                    $cid = $this->obtener_estudiante_desde_loo_correccion($bean);
                    break;
                case "Veta_CorreccionCOE":
                    $cid = $this->obtener_estudiante_desde_coe_correccion($bean);
                    break;
                case "Veta_Visa":
                    $cid = $this->obtener_estudiante_desde_visa($bean);
                    break;
                case "Veta_Liquidacion":
                    $cid = $this->obtener_estudiante_desde_liquidacion($bean);
                    break;
                case "Veta_Pagos":
                    $cid = $this->obtener_estudiante_desde_pagos($bean);
                    break;
                case "Veta_PagoColegios":
                    $cid = $this->obtener_estudiante_desde_pagos_colegios($bean);
                    break;
                case "Veta_NotificacionPagoColegio":
                    $cid = $this->obtener_estudiante_desde_notificacion_pagos_colegios($bean);
                    break;
                case "aCase":
                    $cid = $bean->contact_id_c;
                    break;
            }
        }

        return $cid;

    }

    private function obtener_estudiante_desde_oportunidad($o)
    {
        $cid = null;
        $es = $o->get_linked_beans('contacts_opportunities_1','Contacts');

        foreach( $es as $e )
        {
            $cid = $e->id;
        }

        return $cid;
    }

    private function obtener_estudiante_desde_app($app)
    {
        $cid = null;

        $ops = $app->get_linked_beans('veta_aplicacion_opportunities','Opportunities');

        foreach( $ops as $o )
        {
            $cid = $this->obtener_estudiante_desde_oportunidad($o);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_loo($loo)
    {
        $cid = null;

        $apps = $loo->get_linked_beans('veta_loo_veta_aplicacion','Veta_Aplicacion');

        foreach( $apps as $app )
        {
            $cid = $this->obtener_estudiante_desde_app($app);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_coe($coe)
    {
        $cid = null;

        $apps = $coe->get_linked_beans('veta_coe_veta_aplicacion','Veta_Aplicacion');

        foreach( $apps as $app )
        {
            $cid = $this->obtener_estudiante_desde_app($app);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_loo_correccion($correccion)
    {
        $cid = null;

        $loos = $correccion->get_linked_beans('veta_loocorreccion_veta_loo','Veta_Loo');

        foreach( $loos as $loo )
        {
            $cid = $this->obtener_estudiante_desde_loo($loo);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_coe_correccion($correccion)
    {
        $cid = null;

        $coes = $correccion->get_linked_beans('veta_correccioncoe_veta_coe','Veta_COE');

        foreach( $coes as $coe )
        {
            $cid = $this->obtener_estudiante_desde_coe($coe);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_visa($visa)
    {
        $cid = null;

        $coes = $visa->get_linked_beans('veta_visa_veta_coe','Veta_COE');

        foreach( $coes as $coe )
        {
            $cid = $this->obtener_estudiante_desde_coe($coe);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_liquidacion($l)
    {
        $cid = null;

        $ops = $l->get_linked_beans('veta_liquidacion_opportunities','Opportunities');

        foreach( $ops as $o )
        {
            $cid = $this->obtener_estudiante_desde_oportunidad($o);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_pagos($pago)
    {
        $cid = null;

        $ls = $pago->get_linked_beans('veta_pagos_veta_liquidacion','Veta_Liquidacion');

        foreach( $ls as $l )
        {
            $cid = $this->obtener_estudiante_desde_liquidacion($l);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_pagos_colegios($pago)
    {
        $cid = null;

        $ops = $pago->get_linked_beans('veta_pagocolegios_opportunities','Opportunities');

        foreach( $ops as $o )
        {
            $cid = $this->obtener_estudiante_desde_oportunidad($o);
        }

        return $cid;
    }

    private function obtener_estudiante_desde_notificacion_pagos_colegios($notificacion)
    {
        $cid = null;

        $pagos = $notificacion->get_linked_beans('veta_notificacionpagocolegio_veta_pagocolegios','Veta_PagoColegios');

        foreach( $pagos as $p )
        {
            $cid = $this->obtener_estudiante_desde_pagos_colegios($p);
        }

        return $cid;
    }

}