<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['after_save'] = Array(); 
$hook_array['after_save'][] = Array(77, 'updateMeetingGeocodeInfo', 'modules/Meetings/MeetingsJjwg_MapsLogicHook.php','MeetingsJjwg_MapsLogicHook', 'updateMeetingGeocodeInfo');
$hook_array['after_save'][] = Array(81, 'actualizar_oportunidad', 'custom/modules/Meetings/SOELMeetingsHooks.php','SOELMeetingsHooks', 'actualizar_oportunidad');
$hook_array['before_save'][] = Array(78, 'Primera Cita', 'custom/modules/Meetings/SOELHooks.php','SOELHooks', 'enviar_documentacion_primera_cita');
$hook_array['before_save'][] = Array(79, 'Actualizar Prospecto', 'custom/modules/Meetings/SOELHooks.php','SOELHooks', 'actualizar_prospecto');
$hook_array['before_save'][] = Array(80, 'establecer_estudiante', 'custom/modules/Meetings/SOELHooks.php','SOELHooks', 'establecer_estudiante');




?>