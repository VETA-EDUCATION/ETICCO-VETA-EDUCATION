<?php 
 // created: 2019-10-10 12:39:24
$mod_strings['LBL_LEADS'] = 'Prospectos';
$mod_strings['LBL_CONTACT_ID'] = 'ID Estudiante:';
$mod_strings['LBL_LIST_CONTACT'] = 'Estudiante';
$mod_strings['LBL_LIST_CONTACT_NAME'] = 'Estudiante';
$mod_strings['LBL_ESTUDIANTE_CONTACT_ID'] = 'Estudiante (relacionado Estudiante ID)';
$mod_strings['LBL_ESTUDIANTE'] = 'Estudiante';

?>
