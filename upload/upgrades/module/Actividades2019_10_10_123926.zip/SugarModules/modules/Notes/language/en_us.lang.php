<?php 
 // created: 2019-10-10 12:39:24
$mod_strings['LBL_CONTACT_NAME'] = 'Student:';
$mod_strings['LBL_ESTUDIANTE'] = 'Student';
$mod_strings['LBL_LIST_CONTACT_NAME'] = 'Student';
$mod_strings['LBL_CONTACT_ID'] = 'Student ID:';
$mod_strings['LBL_LIST_CONTACT'] = 'Student';
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_VETA_LOO_ACTIVITIES_NOTES_FROM_VETA_LOO_TITLE'] = 'Activities:LOO';
$mod_strings['LBL_VETA_APLICACION_ACTIVITIES_NOTES_FROM_VETA_APLICACION_TITLE'] = 'Activities:Application';
$mod_strings['LBL_VETA_LIQUIDACION_ACTIVITIES_NOTES_FROM_VETA_LIQUIDACION_TITLE'] = 'Activities:Liquidation';
$mod_strings['LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_NOTES_FROM_VETA_PAGOCOLEGIOS_TITLE'] = 'Activities:Payment to Colleges';

?>
