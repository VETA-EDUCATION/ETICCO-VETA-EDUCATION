<?php 
 // created: 2019-10-10 12:39:25
$mod_strings['LBL_LEADS'] = 'Prospectos';
$mod_strings['LBL_CONTACT'] = 'Estudiante:';
$mod_strings['LBL_CONTACT_ID'] = 'ID de Estudiante:';
$mod_strings['LBL_CONTACT_PHONE'] = 'Teléfono de Estudiante:';
$mod_strings['LBL_ESTUDIANTE_CONTACT_ID'] = 'Estudiante (relacionado Estudiante ID)';
$mod_strings['LBL_ESTUDIANTE'] = 'Estudiante';

?>
