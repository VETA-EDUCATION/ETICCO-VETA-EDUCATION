<?php
// created: 2018-07-30 11:24:34
$dictionary["Call"]["fields"]["veta_aplicacion_activities_calls"] = array (
  'name' => 'veta_aplicacion_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_CALLS_FROM_VETA_APLICACION_TITLE',
);
