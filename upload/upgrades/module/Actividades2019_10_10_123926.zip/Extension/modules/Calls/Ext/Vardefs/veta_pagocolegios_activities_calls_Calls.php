<?php
// created: 2018-07-30 11:24:33
$dictionary["Call"]["fields"]["veta_pagocolegios_activities_calls"] = array (
  'name' => 'veta_pagocolegios_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_CALLS_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
