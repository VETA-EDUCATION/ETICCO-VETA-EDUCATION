<?php
// created: 2018-07-30 11:24:33
$dictionary["Call"]["fields"]["veta_coe_activities_calls"] = array (
  'name' => 'veta_coe_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_CALLS_FROM_VETA_COE_TITLE',
);
