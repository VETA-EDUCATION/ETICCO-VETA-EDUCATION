<?php
 // created: 2018-07-13 17:39:31
$dictionary['Call']['fields']['contact_id_c']['inline_edit']=1;

 ?>