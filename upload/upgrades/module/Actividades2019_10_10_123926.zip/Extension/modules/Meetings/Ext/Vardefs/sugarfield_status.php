<?php
 // created: 2018-02-26 11:47:45
$dictionary['Meeting']['fields']['status']['inline_edit']='';
$dictionary['Meeting']['fields']['status']['comments']='Meeting status (ex: Planned, Held, Not held)';
$dictionary['Meeting']['fields']['status']['merge_filter']='disabled';

 ?>