<?php
// created: 2018-07-30 11:24:34
$dictionary["Meeting"]["fields"]["veta_visa_activities_meetings"] = array (
  'name' => 'veta_visa_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_MEETINGS_FROM_VETA_VISA_TITLE',
);
