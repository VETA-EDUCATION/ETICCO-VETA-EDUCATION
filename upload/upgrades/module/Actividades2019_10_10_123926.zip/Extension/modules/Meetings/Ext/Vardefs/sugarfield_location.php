<?php
 // created: 2018-02-26 11:48:26
$dictionary['Meeting']['fields']['location']['inline_edit']='';
$dictionary['Meeting']['fields']['location']['comments']='Meeting location';
$dictionary['Meeting']['fields']['location']['merge_filter']='disabled';

 ?>