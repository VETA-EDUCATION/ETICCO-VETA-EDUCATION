<?php
 // created: 2018-07-13 18:59:04
$dictionary['Meeting']['fields']['estudiante_c']['inline_edit']='';
$dictionary['Meeting']['fields']['estudiante_c']['labelValue']='Estudiante';

 ?>