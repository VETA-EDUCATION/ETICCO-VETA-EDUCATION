<?php
 // created: 2018-02-26 11:48:07
$dictionary['Meeting']['fields']['description']['inline_edit']='';
$dictionary['Meeting']['fields']['description']['comments']='Full text of the note';
$dictionary['Meeting']['fields']['description']['merge_filter']='disabled';

 ?>