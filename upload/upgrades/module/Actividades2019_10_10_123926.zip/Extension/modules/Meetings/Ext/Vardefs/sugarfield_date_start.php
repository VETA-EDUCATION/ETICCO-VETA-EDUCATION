<?php
 // created: 2018-02-26 11:47:53
$dictionary['Meeting']['fields']['date_start']['inline_edit']='';
$dictionary['Meeting']['fields']['date_start']['comments']='Date of start of meeting';
$dictionary['Meeting']['fields']['date_start']['merge_filter']='disabled';

 ?>