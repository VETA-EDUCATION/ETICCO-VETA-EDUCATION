<?php
 // created: 2018-02-26 11:48:01
$dictionary['Meeting']['fields']['deleted']['inline_edit']='';
$dictionary['Meeting']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Meeting']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['deleted']['reportable']=true;

 ?>