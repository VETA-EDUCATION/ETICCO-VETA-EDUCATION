<?php
// created: 2018-07-30 11:24:33
$dictionary["Meeting"]["fields"]["veta_liquidacion_activities_meetings"] = array (
  'name' => 'veta_liquidacion_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_MEETINGS_FROM_VETA_LIQUIDACION_TITLE',
);
