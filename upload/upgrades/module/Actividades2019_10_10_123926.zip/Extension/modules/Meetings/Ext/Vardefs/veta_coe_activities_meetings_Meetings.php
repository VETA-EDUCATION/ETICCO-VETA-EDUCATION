<?php
// created: 2018-07-30 11:24:33
$dictionary["Meeting"]["fields"]["veta_coe_activities_meetings"] = array (
  'name' => 'veta_coe_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_MEETINGS_FROM_VETA_COE_TITLE',
);
