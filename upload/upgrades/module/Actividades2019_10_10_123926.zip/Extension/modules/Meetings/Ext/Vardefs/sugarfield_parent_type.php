<?php
 // created: 2018-02-26 11:48:16
$dictionary['Meeting']['fields']['parent_type']['inline_edit']='';
$dictionary['Meeting']['fields']['parent_type']['options']='';
$dictionary['Meeting']['fields']['parent_type']['comments']='Module meeting is associated with';
$dictionary['Meeting']['fields']['parent_type']['merge_filter']='disabled';

 ?>