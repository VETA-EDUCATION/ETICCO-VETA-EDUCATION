<?php
 // created: 2018-07-15 14:10:01
$dictionary['Note']['fields']['estudiante_c']['inline_edit']='';
$dictionary['Note']['fields']['estudiante_c']['labelValue']='Estudiante';

 ?>