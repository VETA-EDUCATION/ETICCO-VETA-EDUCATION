<?php
// created: 2018-07-30 11:24:33
$dictionary["Note"]["fields"]["veta_coe_activities_notes"] = array (
  'name' => 'veta_coe_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_NOTES_FROM_VETA_COE_TITLE',
);
