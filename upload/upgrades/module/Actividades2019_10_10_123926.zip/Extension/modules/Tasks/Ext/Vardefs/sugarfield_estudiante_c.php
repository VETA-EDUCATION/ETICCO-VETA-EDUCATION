<?php
 // created: 2018-07-13 17:44:45
$dictionary['Task']['fields']['estudiante_c']['inline_edit']='';
$dictionary['Task']['fields']['estudiante_c']['labelValue']='Estudiante';

 ?>