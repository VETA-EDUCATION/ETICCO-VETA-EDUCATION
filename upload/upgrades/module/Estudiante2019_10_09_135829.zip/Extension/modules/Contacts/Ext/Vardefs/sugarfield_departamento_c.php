<?php
 // created: 2018-02-17 09:35:16
$dictionary['Contact']['fields']['departamento_c']['inline_edit']='';
$dictionary['Contact']['fields']['departamento_c']['labelValue']='Departamento';

 ?>