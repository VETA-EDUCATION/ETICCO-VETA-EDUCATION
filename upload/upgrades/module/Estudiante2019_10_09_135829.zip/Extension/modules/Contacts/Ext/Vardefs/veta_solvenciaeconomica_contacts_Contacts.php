<?php
// created: 2018-07-30 11:24:33
$dictionary["Contact"]["fields"]["veta_solvenciaeconomica_contacts"] = array (
  'name' => 'veta_solvenciaeconomica_contacts',
  'type' => 'link',
  'relationship' => 'veta_solvenciaeconomica_contacts',
  'source' => 'non-db',
  'module' => 'Veta_SolvenciaEconomica',
  'bean_name' => 'Veta_SolvenciaEconomica',
  'side' => 'right',
  'vname' => 'LBL_VETA_SOLVENCIAECONOMICA_CONTACTS_FROM_VETA_SOLVENCIAECONOMICA_TITLE',
);
