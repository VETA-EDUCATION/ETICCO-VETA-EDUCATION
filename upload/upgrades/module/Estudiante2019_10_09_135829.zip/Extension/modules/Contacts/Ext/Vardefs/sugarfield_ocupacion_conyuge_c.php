<?php
 // created: 2018-02-17 09:52:05
$dictionary['Contact']['fields']['ocupacion_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['ocupacion_conyuge_c']['labelValue']='Ocupación Conyuge';

 ?>