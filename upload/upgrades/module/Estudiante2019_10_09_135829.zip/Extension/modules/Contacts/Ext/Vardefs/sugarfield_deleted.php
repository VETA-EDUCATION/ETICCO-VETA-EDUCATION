<?php
 // created: 2018-02-17 16:56:32
$dictionary['Contact']['fields']['deleted']['inline_edit']='';
$dictionary['Contact']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Contact']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Contact']['fields']['deleted']['reportable']=true;

 ?>