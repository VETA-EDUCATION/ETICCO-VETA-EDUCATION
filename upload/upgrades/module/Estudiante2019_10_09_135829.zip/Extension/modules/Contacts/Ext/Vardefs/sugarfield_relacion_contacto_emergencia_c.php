<?php
 // created: 2018-02-17 09:53:53
$dictionary['Contact']['fields']['relacion_contacto_emergencia_c']['inline_edit']='';
$dictionary['Contact']['fields']['relacion_contacto_emergencia_c']['labelValue']='Relación Contacto Emergencia';

 ?>