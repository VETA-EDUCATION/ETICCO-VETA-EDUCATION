<?php
 // created: 2018-02-17 09:34:08
$dictionary['Contact']['fields']['pais_c']['inline_edit']='';
$dictionary['Contact']['fields']['pais_c']['labelValue']='Pais';

 ?>