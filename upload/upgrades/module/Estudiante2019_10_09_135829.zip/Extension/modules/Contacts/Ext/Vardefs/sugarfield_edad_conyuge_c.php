<?php
 // created: 2018-02-17 09:43:49
$dictionary['Contact']['fields']['edad_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['edad_conyuge_c']['labelValue']='Edad Conyuge';

 ?>