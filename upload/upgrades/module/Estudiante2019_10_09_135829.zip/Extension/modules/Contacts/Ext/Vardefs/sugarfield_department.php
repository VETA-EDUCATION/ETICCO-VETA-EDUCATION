<?php
 // created: 2018-02-17 09:35:39
$dictionary['Contact']['fields']['department']['inline_edit']=true;
$dictionary['Contact']['fields']['department']['comments']='The department of the contact';
$dictionary['Contact']['fields']['department']['merge_filter']='disabled';

 ?>