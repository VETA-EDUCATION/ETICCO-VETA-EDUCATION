<?php
 // created: 2018-02-17 09:47:51
$dictionary['Contact']['fields']['institucion_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['institucion_australia_c']['labelValue']='Institucion Australia';

 ?>