<?php
 // created: 2018-02-17 09:51:32
$dictionary['Contact']['fields']['nombre_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['nombre_conyuge_c']['labelValue']='Nombre Conyuge';

 ?>