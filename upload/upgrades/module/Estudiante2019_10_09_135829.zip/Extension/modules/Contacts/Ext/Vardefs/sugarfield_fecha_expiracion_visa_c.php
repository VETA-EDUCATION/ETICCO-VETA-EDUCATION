<?php
 // created: 2019-09-17 16:12:45
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['labelValue']='Visa Expiration Date';

 ?>