<?php
 // created: 2018-02-17 09:37:00
$dictionary['Contact']['fields']['ciudad_c']['inline_edit']='';
$dictionary['Contact']['fields']['ciudad_c']['labelValue']='Ciudad';

 ?>