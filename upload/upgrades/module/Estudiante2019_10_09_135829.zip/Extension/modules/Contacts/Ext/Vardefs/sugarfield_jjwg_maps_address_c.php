<?php
 // created: 2018-02-16 14:47:35
$dictionary['Contact']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>