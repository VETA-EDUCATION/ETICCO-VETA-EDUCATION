<?php
 // created: 2018-02-17 16:56:48
$dictionary['Contact']['fields']['description']['inline_edit']='';
$dictionary['Contact']['fields']['description']['comments']='Full text of the note';
$dictionary['Contact']['fields']['description']['merge_filter']='disabled';

 ?>