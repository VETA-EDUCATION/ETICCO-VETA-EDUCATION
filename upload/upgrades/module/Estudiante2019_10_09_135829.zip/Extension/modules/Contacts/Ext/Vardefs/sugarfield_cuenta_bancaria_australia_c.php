<?php
 // created: 2018-02-17 09:41:20
$dictionary['Contact']['fields']['cuenta_bancaria_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['cuenta_bancaria_australia_c']['labelValue']='Cuenta Bancaria Australia';

 ?>