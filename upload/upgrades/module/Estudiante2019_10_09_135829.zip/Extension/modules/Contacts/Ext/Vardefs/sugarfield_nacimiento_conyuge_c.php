<?php
 // created: 2018-02-17 09:48:39
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['labelValue']='Fecha de Nacimiento Conyuge';

 ?>