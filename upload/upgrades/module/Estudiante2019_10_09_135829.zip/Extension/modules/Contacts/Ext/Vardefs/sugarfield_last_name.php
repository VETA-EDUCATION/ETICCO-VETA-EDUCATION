<?php
 // created: 2018-02-17 16:59:36
$dictionary['Contact']['fields']['last_name']['inline_edit']='';
$dictionary['Contact']['fields']['last_name']['comments']='Last name of the contact';
$dictionary['Contact']['fields']['last_name']['merge_filter']='disabled';

 ?>