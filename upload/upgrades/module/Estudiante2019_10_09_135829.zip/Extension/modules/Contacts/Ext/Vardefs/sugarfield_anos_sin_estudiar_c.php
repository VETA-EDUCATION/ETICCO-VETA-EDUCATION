<?php
 // created: 2018-02-17 09:31:43
$dictionary['Contact']['fields']['anos_sin_estudiar_c']['inline_edit']='';
$dictionary['Contact']['fields']['anos_sin_estudiar_c']['options']='numeric_range_search_dom';
$dictionary['Contact']['fields']['anos_sin_estudiar_c']['labelValue']='Años sin Estudiar';
$dictionary['Contact']['fields']['anos_sin_estudiar_c']['enable_range_search']='1';

 ?>