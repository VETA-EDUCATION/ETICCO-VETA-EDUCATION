<?php
$dictionary['Veta_Loo']['fields']['soel_comercial_requerimiento'] = array(
    'name' => 'soel_comercial_requerimiento',
    'vname' => 'LBL_SOEL_COMERCIAL_REQUERIMIENTO',
    'type' => 'enum',
    'source' => 'non-db',
    'function' => 'getAsignadoLeads',
    'massupdate' => false,
);
