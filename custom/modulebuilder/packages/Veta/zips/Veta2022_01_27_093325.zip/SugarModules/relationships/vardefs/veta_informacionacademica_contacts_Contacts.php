<?php
// created: 2022-01-27 09:33:18
$dictionary["Contact"]["fields"]["veta_informacionacademica_contacts"] = array (
  'name' => 'veta_informacionacademica_contacts',
  'type' => 'link',
  'relationship' => 'veta_informacionacademica_contacts',
  'source' => 'non-db',
  'module' => 'Veta_InformacionAcademica',
  'bean_name' => 'Veta_InformacionAcademica',
  'side' => 'right',
  'vname' => 'LBL_VETA_INFORMACIONACADEMICA_CONTACTS_FROM_VETA_INFORMACIONACADEMICA_TITLE',
);
