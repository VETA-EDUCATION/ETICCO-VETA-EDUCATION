<?php
// created: 2022-01-27 09:33:17
$dictionary["Note"]["fields"]["veta_loo_activities_notes"] = array (
  'name' => 'veta_loo_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_NOTES_FROM_VETA_LOO_TITLE',
);
