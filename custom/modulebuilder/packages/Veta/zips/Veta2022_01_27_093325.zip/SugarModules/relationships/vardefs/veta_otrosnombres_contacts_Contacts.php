<?php
// created: 2022-01-27 09:33:20
$dictionary["Contact"]["fields"]["veta_otrosnombres_contacts"] = array (
  'name' => 'veta_otrosnombres_contacts',
  'type' => 'link',
  'relationship' => 'veta_otrosnombres_contacts',
  'source' => 'non-db',
  'module' => 'Veta_OtrosNombres',
  'bean_name' => 'Veta_OtrosNombres',
  'side' => 'right',
  'vname' => 'LBL_VETA_OTROSNOMBRES_CONTACTS_FROM_VETA_OTROSNOMBRES_TITLE',
);
