<?php
// created: 2022-01-27 09:33:17
$dictionary["Veta_Aplicacion"]["fields"]["veta_loo_veta_aplicacion"] = array (
  'name' => 'veta_loo_veta_aplicacion',
  'type' => 'link',
  'relationship' => 'veta_loo_veta_aplicacion',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'side' => 'right',
  'vname' => 'LBL_VETA_LOO_VETA_APLICACION_FROM_VETA_LOO_TITLE',
);
