<?php
// created: 2022-01-27 09:33:16
$dictionary["Task"]["fields"]["veta_aplicacion_activities_tasks"] = array (
  'name' => 'veta_aplicacion_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_tasks',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_TASKS_FROM_VETA_APLICACION_TITLE',
);
