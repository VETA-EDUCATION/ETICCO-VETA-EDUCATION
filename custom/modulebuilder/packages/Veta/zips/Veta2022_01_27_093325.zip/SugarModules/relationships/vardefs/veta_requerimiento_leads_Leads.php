<?php
// created: 2022-01-27 09:33:24
$dictionary["Lead"]["fields"]["veta_requerimiento_leads"] = array (
  'name' => 'veta_requerimiento_leads',
  'type' => 'link',
  'relationship' => 'veta_requerimiento_leads',
  'source' => 'non-db',
  'module' => 'Veta_Requerimiento',
  'bean_name' => 'Veta_Requerimiento',
  'side' => 'right',
  'vname' => 'LBL_VETA_REQUERIMIENTO_LEADS_FROM_VETA_REQUERIMIENTO_TITLE',
);
