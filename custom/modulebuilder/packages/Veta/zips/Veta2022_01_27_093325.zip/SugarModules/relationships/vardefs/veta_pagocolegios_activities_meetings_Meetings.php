<?php
// created: 2022-01-27 09:33:22
$dictionary["Meeting"]["fields"]["veta_pagocolegios_activities_meetings"] = array (
  'name' => 'veta_pagocolegios_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_MEETINGS_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
