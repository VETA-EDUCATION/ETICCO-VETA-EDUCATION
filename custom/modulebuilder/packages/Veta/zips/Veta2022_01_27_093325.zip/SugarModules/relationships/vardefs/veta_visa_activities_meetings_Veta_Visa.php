<?php
// created: 2022-01-27 09:33:19
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_meetings"] = array (
  'name' => 'veta_visa_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
