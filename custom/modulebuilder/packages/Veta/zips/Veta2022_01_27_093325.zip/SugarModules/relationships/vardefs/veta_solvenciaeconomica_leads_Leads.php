<?php
// created: 2022-01-27 09:33:22
$dictionary["Lead"]["fields"]["veta_solvenciaeconomica_leads"] = array (
  'name' => 'veta_solvenciaeconomica_leads',
  'type' => 'link',
  'relationship' => 'veta_solvenciaeconomica_leads',
  'source' => 'non-db',
  'module' => 'Veta_SolvenciaEconomica',
  'bean_name' => 'Veta_SolvenciaEconomica',
  'side' => 'right',
  'vname' => 'LBL_VETA_SOLVENCIAECONOMICA_LEADS_FROM_VETA_SOLVENCIAECONOMICA_TITLE',
);
