<?php
// created: 2022-01-27 09:33:22
$dictionary["Call"]["fields"]["veta_pagocolegios_activities_calls"] = array (
  'name' => 'veta_pagocolegios_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_CALLS_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
