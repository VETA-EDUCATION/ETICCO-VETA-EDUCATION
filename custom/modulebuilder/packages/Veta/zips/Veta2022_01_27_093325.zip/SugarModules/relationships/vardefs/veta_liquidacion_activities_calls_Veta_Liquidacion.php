<?php
// created: 2022-01-27 09:33:21
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_calls"] = array (
  'name' => 'veta_liquidacion_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
