<?php
// created: 2022-01-27 09:33:21
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_tasks"] = array (
  'name' => 'veta_liquidacion_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
