<?php
 // created: 2022-01-27 09:33:22
$layout_defs["Opportunities"]["subpanel_setup"]['veta_pagocolegios_opportunities'] = array (
  'order' => 100,
  'module' => 'Veta_PagoColegios',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_VETA_PAGOCOLEGIOS_OPPORTUNITIES_FROM_VETA_PAGOCOLEGIOS_TITLE',
  'get_subpanel_data' => 'veta_pagocolegios_opportunities',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
