<?php
// created: 2022-01-27 09:33:20
$dictionary["Lead"]["fields"]["veta_otrosnombres_leads"] = array (
  'name' => 'veta_otrosnombres_leads',
  'type' => 'link',
  'relationship' => 'veta_otrosnombres_leads',
  'source' => 'non-db',
  'module' => 'Veta_OtrosNombres',
  'bean_name' => 'Veta_OtrosNombres',
  'side' => 'right',
  'vname' => 'LBL_VETA_OTROSNOMBRES_LEADS_FROM_VETA_OTROSNOMBRES_TITLE',
);
