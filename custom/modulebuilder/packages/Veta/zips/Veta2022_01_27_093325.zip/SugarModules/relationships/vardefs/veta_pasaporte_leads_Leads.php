<?php
// created: 2022-01-27 09:33:21
$dictionary["Lead"]["fields"]["veta_pasaporte_leads"] = array (
  'name' => 'veta_pasaporte_leads',
  'type' => 'link',
  'relationship' => 'veta_pasaporte_leads',
  'source' => 'non-db',
  'module' => 'Veta_Pasaporte',
  'bean_name' => 'Veta_Pasaporte',
  'side' => 'right',
  'vname' => 'LBL_VETA_PASAPORTE_LEADS_FROM_VETA_PASAPORTE_TITLE',
);
