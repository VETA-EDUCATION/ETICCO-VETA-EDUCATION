<?php
// created: 2022-01-27 09:33:21
$dictionary["Task"]["fields"]["veta_liquidacion_activities_tasks"] = array (
  'name' => 'veta_liquidacion_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_tasks',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_TASKS_FROM_VETA_LIQUIDACION_TITLE',
);
