<?php
// created: 2019-12-05 18:00:54
$dictionary["Opportunity"]["fields"]["veta_liquidacion_opportunities"] = array (
  'name' => 'veta_liquidacion_opportunities',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_opportunities',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'side' => 'right',
  'vname' => 'LBL_VETA_LIQUIDACION_OPPORTUNITIES_FROM_VETA_LIQUIDACION_TITLE',
);
