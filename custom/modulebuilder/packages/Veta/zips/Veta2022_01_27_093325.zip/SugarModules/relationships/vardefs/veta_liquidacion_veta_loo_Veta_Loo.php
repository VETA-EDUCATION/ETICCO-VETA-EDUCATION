<?php
// created: 2022-01-27 09:33:21
$dictionary["Veta_Loo"]["fields"]["veta_liquidacion_veta_loo"] = array (
  'name' => 'veta_liquidacion_veta_loo',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_veta_loo',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'side' => 'right',
  'vname' => 'LBL_VETA_LIQUIDACION_VETA_LOO_FROM_VETA_LIQUIDACION_TITLE',
);
