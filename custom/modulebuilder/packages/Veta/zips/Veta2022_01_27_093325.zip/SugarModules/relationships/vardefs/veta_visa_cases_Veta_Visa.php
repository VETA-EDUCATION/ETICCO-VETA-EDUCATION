<?php
// created: 2022-01-27 09:33:19
$dictionary["Veta_Visa"]["fields"]["veta_visa_cases"] = array (
  'name' => 'veta_visa_cases',
  'type' => 'link',
  'relationship' => 'veta_visa_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_VISA_CASES_FROM_CASES_TITLE',
);
