<?php
// created: 2022-01-27 09:33:16
$dictionary["Veta_COE"]["fields"]["veta_coe_cases"] = array (
  'name' => 'veta_coe_cases',
  'type' => 'link',
  'relationship' => 'veta_coe_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_COE_CASES_FROM_CASES_TITLE',
);
