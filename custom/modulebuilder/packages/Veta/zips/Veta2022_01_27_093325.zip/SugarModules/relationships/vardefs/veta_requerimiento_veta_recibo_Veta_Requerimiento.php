<?php
// created: 2022-01-27 09:33:24
$dictionary["Veta_Requerimiento"]["fields"]["veta_requerimiento_veta_recibo"] = array (
  'name' => 'veta_requerimiento_veta_recibo',
  'type' => 'link',
  'relationship' => 'veta_requerimiento_veta_recibo',
  'source' => 'non-db',
  'module' => 'Veta_Recibo',
  'bean_name' => 'Veta_Recibo',
  'side' => 'right',
  'vname' => 'LBL_VETA_REQUERIMIENTO_VETA_RECIBO_FROM_VETA_RECIBO_TITLE',
);
