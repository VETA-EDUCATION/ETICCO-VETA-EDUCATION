<?php
// created: 2022-01-27 09:33:23
$dictionary["Veta_COE"]["fields"]["veta_correccioncoe_veta_coe"] = array (
  'name' => 'veta_correccioncoe_veta_coe',
  'type' => 'link',
  'relationship' => 'veta_correccioncoe_veta_coe',
  'source' => 'non-db',
  'module' => 'Veta_CorreccionCOE',
  'bean_name' => 'Veta_CorreccionCOE',
  'side' => 'right',
  'vname' => 'LBL_VETA_CORRECCIONCOE_VETA_COE_FROM_VETA_CORRECCIONCOE_TITLE',
);
