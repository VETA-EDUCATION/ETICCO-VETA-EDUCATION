<?php
// created: 2019-12-17 13:18:40
$dictionary["Veta_COE"]["fields"]["veta_visa_veta_coe"] = array (
  'name' => 'veta_visa_veta_coe',
  'type' => 'link',
  'relationship' => 'veta_visa_veta_coe',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'side' => 'right',
  'vname' => 'LBL_VETA_VISA_VETA_COE_FROM_VETA_VISA_TITLE',
);
