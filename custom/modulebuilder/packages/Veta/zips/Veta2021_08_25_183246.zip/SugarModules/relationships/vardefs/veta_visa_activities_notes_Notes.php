<?php
// created: 2021-08-25 18:32:43
$dictionary["Note"]["fields"]["veta_visa_activities_notes"] = array (
  'name' => 'veta_visa_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_NOTES_FROM_VETA_VISA_TITLE',
);
