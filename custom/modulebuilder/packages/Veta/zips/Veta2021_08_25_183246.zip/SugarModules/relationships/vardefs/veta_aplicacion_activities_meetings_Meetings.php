<?php
// created: 2021-08-25 18:32:41
$dictionary["Meeting"]["fields"]["veta_aplicacion_activities_meetings"] = array (
  'name' => 'veta_aplicacion_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_MEETINGS_FROM_VETA_APLICACION_TITLE',
);
