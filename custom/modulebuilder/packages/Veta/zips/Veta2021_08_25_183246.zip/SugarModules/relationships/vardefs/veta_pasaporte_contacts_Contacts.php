<?php
// created: 2021-08-25 18:32:44
$dictionary["Contact"]["fields"]["veta_pasaporte_contacts"] = array (
  'name' => 'veta_pasaporte_contacts',
  'type' => 'link',
  'relationship' => 'veta_pasaporte_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Pasaporte',
  'bean_name' => 'Veta_Pasaporte',
  'side' => 'right',
  'vname' => 'LBL_VETA_PASAPORTE_CONTACTS_FROM_VETA_PASAPORTE_TITLE',
);
