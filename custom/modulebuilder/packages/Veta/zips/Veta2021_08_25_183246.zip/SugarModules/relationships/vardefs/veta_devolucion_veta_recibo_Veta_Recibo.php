<?php
// created: 2021-08-25 18:32:40
$dictionary["Veta_Recibo"]["fields"]["veta_devolucion_veta_recibo"] = array (
  'name' => 'veta_devolucion_veta_recibo',
  'type' => 'link',
  'relationship' => 'veta_devolucion_veta_recibo',
  'source' => 'non-db',
  'module' => 'Veta_Devolucion',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_VETA_DEVOLUCION_VETA_RECIBO_FROM_VETA_DEVOLUCION_TITLE',
);
