<?php
// created: 2021-08-25 18:32:42
$dictionary["Email"]["fields"]["veta_pagocolegios_activities_emails"] = array (
  'name' => 'veta_pagocolegios_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_EMAILS_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
