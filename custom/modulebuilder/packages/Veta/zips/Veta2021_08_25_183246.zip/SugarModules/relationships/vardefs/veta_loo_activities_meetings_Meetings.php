<?php
// created: 2021-08-25 18:32:42
$dictionary["Meeting"]["fields"]["veta_loo_activities_meetings"] = array (
  'name' => 'veta_loo_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_MEETINGS_FROM_VETA_LOO_TITLE',
);
