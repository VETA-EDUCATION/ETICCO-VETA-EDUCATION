<?php
// created: 2021-08-25 18:32:42
$dictionary["Email"]["fields"]["veta_loo_activities_emails"] = array (
  'name' => 'veta_loo_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_EMAILS_FROM_VETA_LOO_TITLE',
);
