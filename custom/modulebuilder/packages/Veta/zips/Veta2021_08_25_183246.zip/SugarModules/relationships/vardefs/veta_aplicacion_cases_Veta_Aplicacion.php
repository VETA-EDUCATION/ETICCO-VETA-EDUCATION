<?php
// created: 2021-08-25 18:32:41
$dictionary["Veta_Aplicacion"]["fields"]["veta_aplicacion_cases"] = array (
  'name' => 'veta_aplicacion_cases',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_APLICACION_CASES_FROM_CASES_TITLE',
);
