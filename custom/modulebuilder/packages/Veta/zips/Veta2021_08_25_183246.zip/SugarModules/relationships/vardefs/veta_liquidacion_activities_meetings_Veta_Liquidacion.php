<?php
// created: 2021-08-25 18:32:40
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_meetings"] = array (
  'name' => 'veta_liquidacion_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
