<?php
// created: 2021-08-25 18:32:45
$dictionary["Veta_Recibo"]["fields"]["veta_detallereciboitem_veta_recibo"] = array (
  'name' => 'veta_detallereciboitem_veta_recibo',
  'type' => 'link',
  'relationship' => 'veta_detallereciboitem_veta_recibo',
  'source' => 'non-db',
  'module' => 'Veta_DetalleReciboItem',
  'bean_name' => 'Veta_DetalleReciboItem',
  'side' => 'right',
  'vname' => 'LBL_VETA_DETALLERECIBOITEM_VETA_RECIBO_FROM_VETA_DETALLERECIBOITEM_TITLE',
);
