<?php
// created: 2021-08-25 18:32:39
$dictionary["Contact"]["fields"]["veta_informacionlaboral_contacts"] = array (
  'name' => 'veta_informacionlaboral_contacts',
  'type' => 'link',
  'relationship' => 'veta_informacionlaboral_contacts',
  'source' => 'non-db',
  'module' => 'Veta_InformacionLaboral',
  'bean_name' => 'Veta_InformacionLaboral',
  'side' => 'right',
  'vname' => 'LBL_VETA_INFORMACIONLABORAL_CONTACTS_FROM_VETA_INFORMACIONLABORAL_TITLE',
);
