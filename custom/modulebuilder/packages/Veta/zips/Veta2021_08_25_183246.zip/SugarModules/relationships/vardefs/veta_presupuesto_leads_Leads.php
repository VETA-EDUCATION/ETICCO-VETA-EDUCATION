<?php
// created: 2021-08-25 18:32:41
$dictionary["Lead"]["fields"]["veta_presupuesto_leads"] = array (
  'name' => 'veta_presupuesto_leads',
  'type' => 'link',
  'relationship' => 'veta_presupuesto_leads',
  'source' => 'non-db',
  'module' => 'Veta_Presupuesto',
  'bean_name' => 'Veta_Presupuesto',
  'side' => 'right',
  'vname' => 'LBL_VETA_PRESUPUESTO_LEADS_FROM_VETA_PRESUPUESTO_TITLE',
);
