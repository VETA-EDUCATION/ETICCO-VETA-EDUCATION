<?php
// created: 2021-08-25 18:32:42
$dictionary["Lead"]["fields"]["veta_serviciosadicionales_leads"] = array (
  'name' => 'veta_serviciosadicionales_leads',
  'type' => 'link',
  'relationship' => 'veta_serviciosadicionales_leads',
  'source' => 'non-db',
  'module' => 'Veta_ServiciosAdicionales',
  'bean_name' => 'Veta_ServiciosAdicionales',
  'side' => 'right',
  'vname' => 'LBL_VETA_SERVICIOSADICIONALES_LEADS_FROM_VETA_SERVICIOSADICIONALES_TITLE',
);
