<?php
// created: 2021-08-25 18:32:43
$dictionary["Task"]["fields"]["veta_visa_activities_tasks"] = array (
  'name' => 'veta_visa_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_tasks',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_TASKS_FROM_VETA_VISA_TITLE',
);
