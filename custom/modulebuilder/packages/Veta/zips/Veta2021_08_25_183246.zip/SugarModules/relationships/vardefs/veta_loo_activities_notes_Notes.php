<?php
// created: 2021-08-25 18:32:42
$dictionary["Note"]["fields"]["veta_loo_activities_notes"] = array (
  'name' => 'veta_loo_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_Loo',
  'bean_name' => 'Veta_Loo',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_NOTES_FROM_VETA_LOO_TITLE',
);
