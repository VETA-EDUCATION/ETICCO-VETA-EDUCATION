<?php
// created: 2021-08-25 18:32:43
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_emails"] = array (
  'name' => 'veta_visa_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
