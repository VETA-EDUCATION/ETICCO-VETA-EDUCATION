<?php
// created: 2021-08-25 18:32:46
$dictionary["Veta_Loo"]["fields"]["veta_loocorreccion_veta_loo"] = array (
  'name' => 'veta_loocorreccion_veta_loo',
  'type' => 'link',
  'relationship' => 'veta_loocorreccion_veta_loo',
  'source' => 'non-db',
  'module' => 'Veta_LooCorreccion',
  'bean_name' => 'Veta_LooCorreccion',
  'side' => 'right',
  'vname' => 'LBL_VETA_LOOCORRECCION_VETA_LOO_FROM_VETA_LOOCORRECCION_TITLE',
);
