<?php
// created: 2021-08-25 18:32:45
$dictionary["Call"]["fields"]["veta_coe_activities_calls"] = array (
  'name' => 'veta_coe_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_CALLS_FROM_VETA_COE_TITLE',
);
