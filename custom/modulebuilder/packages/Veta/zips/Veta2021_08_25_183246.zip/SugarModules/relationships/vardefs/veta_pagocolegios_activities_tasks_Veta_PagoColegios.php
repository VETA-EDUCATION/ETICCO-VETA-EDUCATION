<?php
// created: 2021-08-25 18:32:42
$dictionary["Veta_PagoColegios"]["fields"]["veta_pagocolegios_activities_tasks"] = array (
  'name' => 'veta_pagocolegios_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
