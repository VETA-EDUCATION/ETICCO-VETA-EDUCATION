<?php
// created: 2021-08-25 18:32:46
$dictionary["Lead"]["fields"]["veta_requerimiento_leads"] = array (
  'name' => 'veta_requerimiento_leads',
  'type' => 'link',
  'relationship' => 'veta_requerimiento_leads',
  'source' => 'non-db',
  'module' => 'Veta_Requerimiento',
  'bean_name' => 'Veta_Requerimiento',
  'side' => 'right',
  'vname' => 'LBL_VETA_REQUERIMIENTO_LEADS_FROM_VETA_REQUERIMIENTO_TITLE',
);
