<?php
// created: 2021-08-25 18:32:45
$dictionary["Email"]["fields"]["veta_coe_activities_emails"] = array (
  'name' => 'veta_coe_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_EMAILS_FROM_VETA_COE_TITLE',
);
