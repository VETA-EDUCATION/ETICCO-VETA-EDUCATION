<?php
// created: 2021-08-25 18:32:42
$dictionary["Task"]["fields"]["veta_pagocolegios_activities_tasks"] = array (
  'name' => 'veta_pagocolegios_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_tasks',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_TASKS_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
