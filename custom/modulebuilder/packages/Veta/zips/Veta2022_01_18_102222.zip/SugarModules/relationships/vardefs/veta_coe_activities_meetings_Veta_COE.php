<?php
// created: 2022-01-18 10:22:20
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_meetings"] = array (
  'name' => 'veta_coe_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
