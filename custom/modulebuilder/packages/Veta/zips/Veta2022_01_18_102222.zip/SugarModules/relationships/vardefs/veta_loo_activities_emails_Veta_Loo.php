<?php
// created: 2022-01-18 10:22:16
$dictionary["Veta_Loo"]["fields"]["veta_loo_activities_emails"] = array (
  'name' => 'veta_loo_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
