<?php
// created: 2022-01-18 10:22:22
$dictionary["Contact"]["fields"]["veta_ciudadania_contacts"] = array (
  'name' => 'veta_ciudadania_contacts',
  'type' => 'link',
  'relationship' => 'veta_ciudadania_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Ciudadania',
  'bean_name' => 'Veta_Ciudadania',
  'side' => 'right',
  'vname' => 'LBL_VETA_CIUDADANIA_CONTACTS_FROM_VETA_CIUDADANIA_TITLE',
);
