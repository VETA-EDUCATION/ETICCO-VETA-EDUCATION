<?php
// created: 2022-01-18 10:22:20
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_emails"] = array (
  'name' => 'veta_coe_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
