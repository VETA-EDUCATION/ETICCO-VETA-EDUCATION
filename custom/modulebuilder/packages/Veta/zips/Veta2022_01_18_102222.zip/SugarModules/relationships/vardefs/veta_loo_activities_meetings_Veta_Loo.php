<?php
// created: 2022-01-18 10:22:16
$dictionary["Veta_Loo"]["fields"]["veta_loo_activities_meetings"] = array (
  'name' => 'veta_loo_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
