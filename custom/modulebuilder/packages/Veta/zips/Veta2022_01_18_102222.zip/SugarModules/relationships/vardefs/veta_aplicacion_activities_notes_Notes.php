<?php
// created: 2022-01-18 10:22:15
$dictionary["Note"]["fields"]["veta_aplicacion_activities_notes"] = array (
  'name' => 'veta_aplicacion_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_NOTES_FROM_VETA_APLICACION_TITLE',
);
