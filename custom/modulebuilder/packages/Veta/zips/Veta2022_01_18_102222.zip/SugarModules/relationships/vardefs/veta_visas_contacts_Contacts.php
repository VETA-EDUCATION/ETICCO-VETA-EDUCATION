<?php
// created: 2022-01-18 10:22:17
$dictionary["Contact"]["fields"]["veta_visas_contacts"] = array (
  'name' => 'veta_visas_contacts',
  'type' => 'link',
  'relationship' => 'veta_visas_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Visas',
  'bean_name' => 'Veta_Visas',
  'side' => 'right',
  'vname' => 'LBL_VETA_VISAS_CONTACTS_FROM_VETA_VISAS_TITLE',
);
