<?php
// created: 2022-01-18 10:22:16
$dictionary["Note"]["fields"]["veta_pagocolegios_activities_notes"] = array (
  'name' => 'veta_pagocolegios_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_notes',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_NOTES_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
