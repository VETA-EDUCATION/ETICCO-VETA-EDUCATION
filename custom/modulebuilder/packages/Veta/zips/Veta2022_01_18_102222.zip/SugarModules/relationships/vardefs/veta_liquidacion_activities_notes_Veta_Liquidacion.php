<?php
// created: 2022-01-18 10:22:14
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_notes"] = array (
  'name' => 'veta_liquidacion_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
