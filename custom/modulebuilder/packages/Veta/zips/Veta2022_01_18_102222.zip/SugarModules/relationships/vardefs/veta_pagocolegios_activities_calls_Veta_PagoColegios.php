<?php
// created: 2022-01-18 10:22:16
$dictionary["Veta_PagoColegios"]["fields"]["veta_pagocolegios_activities_calls"] = array (
  'name' => 'veta_pagocolegios_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
