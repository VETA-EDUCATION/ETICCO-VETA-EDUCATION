<?php
// created: 2022-01-18 10:22:18
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_calls"] = array (
  'name' => 'veta_visa_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
