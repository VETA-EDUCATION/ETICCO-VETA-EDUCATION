<?php
// created: 2022-01-18 10:22:15
$dictionary["Contact"]["fields"]["veta_presupuesto_contacts"] = array (
  'name' => 'veta_presupuesto_contacts',
  'type' => 'link',
  'relationship' => 'veta_presupuesto_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Presupuesto',
  'bean_name' => 'Veta_Presupuesto',
  'side' => 'right',
  'vname' => 'LBL_VETA_PRESUPUESTO_CONTACTS_FROM_VETA_PRESUPUESTO_TITLE',
);
