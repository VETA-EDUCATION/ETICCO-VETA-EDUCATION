<?php
$dictionary['Veta_COE']['fields']['soel_oficina_comercial'] = array(
    'name' => 'soel_oficina_comercial',
    'vname' => 'LBL_SOEL_OFICINA_COMERCIAL',
    'type' => 'enum',
    'source' => 'non-db',
    'function' => 'getOficinasComercial',
    'massupdate' => false,
);
