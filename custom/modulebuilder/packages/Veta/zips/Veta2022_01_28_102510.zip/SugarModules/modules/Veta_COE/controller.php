<?php
class Veta_COEController extends SugarController
{
    function action_msg()
    {
        $this->view = 'msg';
    }
    
}

?>
