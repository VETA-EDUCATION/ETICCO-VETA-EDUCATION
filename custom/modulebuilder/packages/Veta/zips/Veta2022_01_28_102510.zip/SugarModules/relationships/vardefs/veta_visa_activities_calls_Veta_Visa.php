<?php
// created: 2022-01-28 10:25:01
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_calls"] = array (
  'name' => 'veta_visa_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
