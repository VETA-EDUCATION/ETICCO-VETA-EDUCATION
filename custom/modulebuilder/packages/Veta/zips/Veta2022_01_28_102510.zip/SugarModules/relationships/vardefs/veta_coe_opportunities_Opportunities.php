<?php
// created: 2022-01-28 10:24:56
$dictionary["Opportunity"]["fields"]["veta_coe_opportunities"] = array (
  'name' => 'veta_coe_opportunities',
  'type' => 'link',
  'relationship' => 'veta_coe_opportunities',
  'source' => 'non-db',
  'module' => 'Veta_COE',
  'bean_name' => 'Veta_COE',
  'side' => 'right',
  'vname' => 'LBL_VETA_COE_OPPORTUNITIES_FROM_VETA_COE_TITLE',
);
