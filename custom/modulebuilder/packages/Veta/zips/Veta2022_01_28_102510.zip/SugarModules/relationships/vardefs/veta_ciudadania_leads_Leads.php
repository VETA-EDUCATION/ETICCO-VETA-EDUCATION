<?php
// created: 2022-01-28 10:24:58
$dictionary["Lead"]["fields"]["veta_ciudadania_leads"] = array (
  'name' => 'veta_ciudadania_leads',
  'type' => 'link',
  'relationship' => 'veta_ciudadania_leads',
  'source' => 'non-db',
  'module' => 'Veta_Ciudadania',
  'bean_name' => 'Veta_Ciudadania',
  'side' => 'right',
  'vname' => 'LBL_VETA_CIUDADANIA_LEADS_FROM_VETA_CIUDADANIA_TITLE',
);
