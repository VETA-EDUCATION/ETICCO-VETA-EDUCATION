<?php
// created: 2022-01-28 10:25:01
$dictionary["Call"]["fields"]["veta_visa_activities_calls"] = array (
  'name' => 'veta_visa_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_CALLS_FROM_VETA_VISA_TITLE',
);
