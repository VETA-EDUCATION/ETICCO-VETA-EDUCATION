<?php
// created: 2022-01-28 10:25:05
$dictionary["Call"]["fields"]["veta_liquidacion_activities_calls"] = array (
  'name' => 'veta_liquidacion_activities_calls',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_calls',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_CALLS_FROM_VETA_LIQUIDACION_TITLE',
);
