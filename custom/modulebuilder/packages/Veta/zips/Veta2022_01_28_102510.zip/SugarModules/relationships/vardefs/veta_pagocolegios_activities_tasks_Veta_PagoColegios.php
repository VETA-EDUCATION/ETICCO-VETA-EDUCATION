<?php
// created: 2022-01-28 10:25:06
$dictionary["Veta_PagoColegios"]["fields"]["veta_pagocolegios_activities_tasks"] = array (
  'name' => 'veta_pagocolegios_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
