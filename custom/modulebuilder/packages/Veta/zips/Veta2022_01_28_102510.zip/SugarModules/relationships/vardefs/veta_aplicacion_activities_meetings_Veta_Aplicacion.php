<?php
// created: 2022-01-28 10:24:57
$dictionary["Veta_Aplicacion"]["fields"]["veta_aplicacion_activities_meetings"] = array (
  'name' => 'veta_aplicacion_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_VETA_APLICACION_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
