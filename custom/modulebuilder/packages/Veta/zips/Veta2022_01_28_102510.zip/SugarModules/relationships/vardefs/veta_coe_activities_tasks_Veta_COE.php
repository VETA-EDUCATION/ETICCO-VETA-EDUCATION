<?php
// created: 2022-01-28 10:24:56
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_tasks"] = array (
  'name' => 'veta_coe_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
