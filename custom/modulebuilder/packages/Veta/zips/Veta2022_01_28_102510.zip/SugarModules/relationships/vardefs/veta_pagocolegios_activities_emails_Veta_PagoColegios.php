<?php
// created: 2022-01-28 10:25:06
$dictionary["Veta_PagoColegios"]["fields"]["veta_pagocolegios_activities_emails"] = array (
  'name' => 'veta_pagocolegios_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
