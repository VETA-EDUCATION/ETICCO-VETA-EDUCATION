<?php
// created: 2022-01-28 10:25:01
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_notes"] = array (
  'name' => 'veta_visa_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
