<?php
// created: 2022-01-28 10:24:57
$dictionary["Veta_Aplicacion"]["fields"]["veta_aplicacion_cases"] = array (
  'name' => 'veta_aplicacion_cases',
  'type' => 'link',
  'relationship' => 'veta_aplicacion_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_APLICACION_CASES_FROM_CASES_TITLE',
);
