<?php
// created: 2022-01-28 10:24:59
$dictionary["Veta_Loo"]["fields"]["veta_loo_activities_tasks"] = array (
  'name' => 'veta_loo_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_loo_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_LOO_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
