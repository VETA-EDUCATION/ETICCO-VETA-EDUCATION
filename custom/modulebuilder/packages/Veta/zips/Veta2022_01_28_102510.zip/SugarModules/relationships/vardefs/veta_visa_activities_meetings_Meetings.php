<?php
// created: 2022-01-28 10:25:01
$dictionary["Meeting"]["fields"]["veta_visa_activities_meetings"] = array (
  'name' => 'veta_visa_activities_meetings',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_meetings',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_MEETINGS_FROM_VETA_VISA_TITLE',
);
