<?php
// created: 2022-01-28 10:25:05
$dictionary["Email"]["fields"]["veta_liquidacion_activities_emails"] = array (
  'name' => 'veta_liquidacion_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_Liquidacion',
  'bean_name' => 'Veta_Liquidacion',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_EMAILS_FROM_VETA_LIQUIDACION_TITLE',
);
