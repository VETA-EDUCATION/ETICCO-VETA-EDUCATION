<?php
// created: 2022-01-28 10:24:59
$dictionary["Lead"]["fields"]["veta_informacionacademica_leads"] = array (
  'name' => 'veta_informacionacademica_leads',
  'type' => 'link',
  'relationship' => 'veta_informacionacademica_leads',
  'source' => 'non-db',
  'module' => 'Veta_InformacionAcademica',
  'bean_name' => 'Veta_InformacionAcademica',
  'side' => 'right',
  'vname' => 'LBL_VETA_INFORMACIONACADEMICA_LEADS_FROM_VETA_INFORMACIONACADEMICA_TITLE',
);
