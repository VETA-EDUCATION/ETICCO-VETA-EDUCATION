<?php
// created: 2022-01-28 10:25:05
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_cases"] = array (
  'name' => 'veta_liquidacion_cases',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'side' => 'right',
  'vname' => 'LBL_VETA_LIQUIDACION_CASES_FROM_CASES_TITLE',
);
