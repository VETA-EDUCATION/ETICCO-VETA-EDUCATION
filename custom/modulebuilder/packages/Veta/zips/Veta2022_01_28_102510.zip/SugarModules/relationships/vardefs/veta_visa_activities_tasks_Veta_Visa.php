<?php
// created: 2022-01-28 10:25:01
$dictionary["Veta_Visa"]["fields"]["veta_visa_activities_tasks"] = array (
  'name' => 'veta_visa_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
