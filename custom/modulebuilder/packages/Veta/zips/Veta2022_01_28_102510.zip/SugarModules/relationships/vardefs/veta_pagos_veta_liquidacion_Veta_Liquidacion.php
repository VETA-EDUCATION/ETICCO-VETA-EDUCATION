<?php
// created: 2022-01-28 10:25:02
$dictionary["Veta_Liquidacion"]["fields"]["veta_pagos_veta_liquidacion"] = array (
  'name' => 'veta_pagos_veta_liquidacion',
  'type' => 'link',
  'relationship' => 'veta_pagos_veta_liquidacion',
  'source' => 'non-db',
  'module' => 'Veta_Pagos',
  'bean_name' => 'Veta_Pagos',
  'side' => 'right',
  'vname' => 'LBL_VETA_PAGOS_VETA_LIQUIDACION_FROM_VETA_PAGOS_TITLE',
);
