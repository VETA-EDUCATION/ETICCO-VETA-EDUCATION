<?php
// created: 2022-01-28 10:24:58
$dictionary["Veta_Recibo"]["fields"]["veta_devolucion_veta_recibo"] = array (
  'name' => 'veta_devolucion_veta_recibo',
  'type' => 'link',
  'relationship' => 'veta_devolucion_veta_recibo',
  'source' => 'non-db',
  'module' => 'Veta_Devolucion',
  'bean_name' => 'Veta_Devolucion',
  'side' => 'right',
  'vname' => 'LBL_VETA_DEVOLUCION_VETA_RECIBO_FROM_VETA_DEVOLUCION_TITLE',
);
