<?php
$dashletData['Veta_PresupuestoDashlet']['searchFields'] = array (
  'tipo_visa' => 
  array (
    'default' => '',
  ),
  'veta_presupuesto_leads_name' => 
  array (
    'default' => '',
  ),
  'veta_presupuesto_contacts_name' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'default' => '',
  ),
);
$dashletData['Veta_PresupuestoDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'pais' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_PAIS',
    'width' => '10%',
    'name' => 'pais',
  ),
  'departamento' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'label' => 'LBL_DEPARTAMENTO',
    'width' => '10%',
    'default' => true,
    'name' => 'departamento',
  ),
  'ciudad' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'label' => 'LBL_CIUDAD',
    'width' => '10%',
    'default' => true,
    'name' => 'ciudad',
  ),
  'primer_pago' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_PRIMER_PAGO',
    'currency_format' => true,
    'width' => '10%',
    'name' => 'primer_pago',
  ),
  'subtotal' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_SUBTOTAL',
    'currency_format' => true,
    'width' => '10%',
    'name' => 'subtotal',
  ),
  'gran_total' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_GRAN_TOTAL',
    'currency_format' => true,
    'width' => '10%',
    'name' => 'gran_total',
  ),
  'tipo_visa' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_TIPO_VISA',
    'id' => 'VETA_TIPOSVISA_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'total_visa' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_TOTAL_VISA',
    'currency_format' => true,
    'width' => '10%',
  ),
  'seguro' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_SEGURO',
    'currency_format' => true,
    'width' => '10%',
  ),
  'examen_medico' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_EXAMEN_MEDICO',
    'currency_format' => true,
    'width' => '10%',
  ),
  'veta_presupuesto_leads_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_PRESUPUESTO_LEADS_FROM_LEADS_TITLE',
    'id' => 'VETA_PRESUPUESTO_LEADSLEADS_IDA',
    'width' => '10%',
    'default' => true,
    'name' => 'veta_presupuesto_leads_name',
  ),
  'veta_presupuesto_contacts_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_PRESUPUESTO_CONTACTS_FROM_CONTACTS_TITLE',
    'id' => 'VETA_PRESUPUESTO_CONTACTSCONTACTS_IDA',
    'width' => '10%',
    'default' => true,
    'name' => 'veta_presupuesto_contacts_name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'usd' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_USD',
    'currency_format' => true,
    'width' => '10%',
    'default' => false,
  ),
  'pesos' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_PESOS',
    'currency_format' => true,
    'width' => '10%',
    'default' => false,
  ),
  'usd_cop' => 
  array (
    'type' => 'int',
    'default' => false,
    'label' => 'LBL_USD_COP',
    'width' => '10%',
  ),
  'aud_usd' => 
  array (
    'type' => 'decimal',
    'default' => false,
    'label' => 'LBL_AUD_USD',
    'width' => '10%',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
