<?php
$module_name='Veta_TRM';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Veta_TRM',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'aud' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_AUD',
      'width' => '10%',
      'default' => true,
    ),
    'pesos' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_PESOS',
      'width' => '10%',
      'default' => true,
    ),
    'mxn' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_MXN',
      'width' => '10%',
    ),
    'clp' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_CLP',
      'width' => '10%',
    ),
    'date_modified' => 
    array (
      'vname' => 'LBL_DATE_MODIFIED',
      'width' => '45%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'Veta_TRM',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'Veta_TRM',
      'width' => '5%',
      'default' => true,
    ),
  ),
);