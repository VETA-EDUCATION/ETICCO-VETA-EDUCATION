<?php
$popupMeta = array (
    'moduleMain' => 'Veta_TRM',
    'varName' => 'Veta_TRM',
    'orderBy' => 'veta_trm.name',
    'whereClauses' => array (
  'name' => 'veta_trm.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
);
