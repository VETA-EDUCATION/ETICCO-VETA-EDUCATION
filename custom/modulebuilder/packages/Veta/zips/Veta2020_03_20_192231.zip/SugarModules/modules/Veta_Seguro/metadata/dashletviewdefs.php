<?php
$dashletData['Veta_SeguroDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'duracion' => 
  array (
    'default' => '',
  ),
);
$dashletData['Veta_SeguroDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'duracion' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_DURACION',
    'width' => '10%',
  ),
  'single' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_SINGLE',
    'width' => '10%',
  ),
  'couple' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_COUPLE',
    'width' => '10%',
  ),
  'family' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_FAMILY',
    'width' => '10%',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
);
