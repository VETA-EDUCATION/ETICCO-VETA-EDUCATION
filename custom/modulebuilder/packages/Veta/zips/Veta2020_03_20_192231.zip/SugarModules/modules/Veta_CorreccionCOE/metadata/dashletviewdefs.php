<?php
$dashletData['Veta_CorreccionCOEDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'fecha_solicitud' => 
  array (
    'default' => '',
  ),
  'fecha_correccion' => 
  array (
    'default' => '',
  ),
  'veta_correccioncoe_veta_coe_name' => 
  array (
    'default' => '',
  ),
);
$dashletData['Veta_CorreccionCOEDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'veta_correccioncoe_veta_coe_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_VETA_CORRECCIONCOE_VETA_COE_FROM_VETA_COE_TITLE',
    'id' => 'VETA_CORRECCIONCOE_VETA_COEVETA_COE_IDA',
    'width' => '10%',
    'default' => true,
    'name' => 'veta_correccioncoe_veta_coe_name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
