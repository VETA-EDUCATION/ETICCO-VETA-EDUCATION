<?php
// created: 2021-09-02 13:15:22
$dictionary["Contact"]["fields"]["veta_presupuesto_contacts"] = array (
  'name' => 'veta_presupuesto_contacts',
  'type' => 'link',
  'relationship' => 'veta_presupuesto_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Presupuesto',
  'bean_name' => 'Veta_Presupuesto',
  'side' => 'right',
  'vname' => 'LBL_VETA_PRESUPUESTO_CONTACTS_FROM_VETA_PRESUPUESTO_TITLE',
);
