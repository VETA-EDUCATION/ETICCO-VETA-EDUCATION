<?php
// created: 2021-09-02 13:15:21
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_notes"] = array (
  'name' => 'veta_liquidacion_activities_notes',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
