<?php
// created: 2021-09-02 13:15:24
$dictionary["Veta_COE"]["fields"]["veta_coe_activities_emails"] = array (
  'name' => 'veta_coe_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_coe_activities_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_VETA_COE_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
