<?php
// created: 2021-09-02 13:15:23
$dictionary["Contact"]["fields"]["veta_serviciosadicionales_contacts"] = array (
  'name' => 'veta_serviciosadicionales_contacts',
  'type' => 'link',
  'relationship' => 'veta_serviciosadicionales_contacts',
  'source' => 'non-db',
  'module' => 'Veta_ServiciosAdicionales',
  'bean_name' => 'Veta_ServiciosAdicionales',
  'side' => 'right',
  'vname' => 'LBL_VETA_SERVICIOSADICIONALES_CONTACTS_FROM_VETA_SERVICIOSADICIONALES_TITLE',
);
