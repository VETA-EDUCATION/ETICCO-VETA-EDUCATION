<?php
// created: 2021-09-02 13:15:24
$dictionary["Contact"]["fields"]["veta_recibo_contacts"] = array (
  'name' => 'veta_recibo_contacts',
  'type' => 'link',
  'relationship' => 'veta_recibo_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Recibo',
  'bean_name' => 'Veta_Recibo',
  'side' => 'right',
  'vname' => 'LBL_VETA_RECIBO_CONTACTS_FROM_VETA_RECIBO_TITLE',
);
