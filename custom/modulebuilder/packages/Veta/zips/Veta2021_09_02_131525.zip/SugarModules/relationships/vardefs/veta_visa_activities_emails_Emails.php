<?php
// created: 2021-09-02 13:15:23
$dictionary["Email"]["fields"]["veta_visa_activities_emails"] = array (
  'name' => 'veta_visa_activities_emails',
  'type' => 'link',
  'relationship' => 'veta_visa_activities_emails',
  'source' => 'non-db',
  'module' => 'Veta_Visa',
  'bean_name' => 'Veta_Visa',
  'vname' => 'LBL_VETA_VISA_ACTIVITIES_EMAILS_FROM_VETA_VISA_TITLE',
);
