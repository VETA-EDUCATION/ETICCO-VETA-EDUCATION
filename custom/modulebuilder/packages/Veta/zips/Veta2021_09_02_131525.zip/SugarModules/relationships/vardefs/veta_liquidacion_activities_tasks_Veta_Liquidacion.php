<?php
// created: 2021-09-02 13:15:21
$dictionary["Veta_Liquidacion"]["fields"]["veta_liquidacion_activities_tasks"] = array (
  'name' => 'veta_liquidacion_activities_tasks',
  'type' => 'link',
  'relationship' => 'veta_liquidacion_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_VETA_LIQUIDACION_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
