<?php
// created: 2021-09-02 13:15:20
$dictionary["Contact"]["fields"]["veta_otrosnombres_contacts"] = array (
  'name' => 'veta_otrosnombres_contacts',
  'type' => 'link',
  'relationship' => 'veta_otrosnombres_contacts',
  'source' => 'non-db',
  'module' => 'Veta_OtrosNombres',
  'bean_name' => 'Veta_OtrosNombres',
  'side' => 'right',
  'vname' => 'LBL_VETA_OTROSNOMBRES_CONTACTS_FROM_VETA_OTROSNOMBRES_TITLE',
);
