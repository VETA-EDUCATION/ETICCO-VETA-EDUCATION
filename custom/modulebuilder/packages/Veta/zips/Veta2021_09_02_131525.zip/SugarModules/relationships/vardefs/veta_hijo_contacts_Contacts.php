<?php
// created: 2019-10-09 12:37:32
$dictionary["Contact"]["fields"]["veta_hijo_contacts"] = array (
  'name' => 'veta_hijo_contacts',
  'type' => 'link',
  'relationship' => 'veta_hijo_contacts',
  'source' => 'non-db',
  'module' => 'Veta_Hijo',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_VETA_HIJO_CONTACTS_FROM_VETA_HIJO_TITLE',
);
