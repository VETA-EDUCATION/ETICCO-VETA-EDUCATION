<?php
// created: 2021-09-02 13:15:25
$dictionary["Veta_DetalleRecibo"]["fields"]["veta_detallereciboitem_veta_detallerecibo"] = array (
  'name' => 'veta_detallereciboitem_veta_detallerecibo',
  'type' => 'link',
  'relationship' => 'veta_detallereciboitem_veta_detallerecibo',
  'source' => 'non-db',
  'module' => 'Veta_DetalleReciboItem',
  'bean_name' => 'Veta_DetalleReciboItem',
  'side' => 'right',
  'vname' => 'LBL_VETA_DETALLERECIBOITEM_VETA_DETALLERECIBO_FROM_VETA_DETALLERECIBOITEM_TITLE',
);
