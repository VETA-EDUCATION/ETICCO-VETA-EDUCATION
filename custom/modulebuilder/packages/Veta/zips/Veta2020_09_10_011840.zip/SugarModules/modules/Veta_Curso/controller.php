<?php

class Veta_CursoController extends SugarController
{

    function action_importar() {
        $this->view = 'importar';
    }


}
