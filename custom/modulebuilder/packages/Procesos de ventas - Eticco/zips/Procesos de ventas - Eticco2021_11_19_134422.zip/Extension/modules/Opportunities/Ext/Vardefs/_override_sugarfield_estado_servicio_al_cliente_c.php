<?php
 // created: 2019-12-05 07:29:58
$dictionary['Opportunity']['fields']['estado_servicio_al_cliente_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_servicio_al_cliente_c']['labelValue']='Estado Servicio al Cliente';

 ?>