<?php
 // created: 2019-11-02 16:57:24
$dictionary['Opportunity']['fields']['estado_recoleccion_documento_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_recoleccion_documento_c']['labelValue']='Estado recolección documentos';

 ?>