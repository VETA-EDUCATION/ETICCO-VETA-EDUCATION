<?php
 // created: 2020-03-16 15:28:07
$dictionary['Opportunity']['fields']['asignado_aplicacion_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['asignado_aplicacion_c']['labelValue']='Asignado Aplicacion';

 ?>