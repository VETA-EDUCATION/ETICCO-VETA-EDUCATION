<?php
 // created: 2019-11-02 17:08:42
$dictionary['Opportunity']['fields']['porcentaje_pago_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['porcentaje_pago_c']['labelValue']='Porcentaje Pago';

 ?>