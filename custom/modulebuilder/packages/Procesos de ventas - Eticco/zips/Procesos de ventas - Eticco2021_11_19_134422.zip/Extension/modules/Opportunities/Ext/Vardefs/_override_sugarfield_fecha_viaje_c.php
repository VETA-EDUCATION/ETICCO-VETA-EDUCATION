<?php
 // created: 2020-03-16 08:52:11
$dictionary['Opportunity']['fields']['fecha_viaje_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_viaje_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_viaje_c']['labelValue']='Fecha de Viaje';
$dictionary['Opportunity']['fields']['fecha_viaje_c']['enable_range_search']='1';

 ?>