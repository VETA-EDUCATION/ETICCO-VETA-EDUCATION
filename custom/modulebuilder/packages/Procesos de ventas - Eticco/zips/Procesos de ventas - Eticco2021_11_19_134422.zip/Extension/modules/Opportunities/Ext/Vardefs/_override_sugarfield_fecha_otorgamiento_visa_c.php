<?php
 // created: 2019-11-02 17:04:19
$dictionary['Opportunity']['fields']['fecha_otorgamiento_visa_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_otorgamiento_visa_c']['labelValue']='Fecha Otorgamiento Visa';

 ?>