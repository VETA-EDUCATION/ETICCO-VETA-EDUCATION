<?php

$dictionary['Opportunity']['fields']['soel_oficina'] = array(
    'name' => 'soel_oficina',
    'vname' => 'LBL_SOEL_OFICINA',
    'type' => 'enum',
    'source' => 'non-db',
    'function' => 'getOficinasComercial',
);