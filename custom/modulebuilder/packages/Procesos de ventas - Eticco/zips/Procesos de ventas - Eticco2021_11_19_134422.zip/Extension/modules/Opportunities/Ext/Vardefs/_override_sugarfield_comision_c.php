<?php
 // created: 2019-11-02 16:55:58
$dictionary['Opportunity']['fields']['comision_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['comision_c']['labelValue']='Comision';

 ?>