<?php

$dictionary['Opportunity']['fields']['soel_campus'] = array(
    'name' => 'soel_campus',
    'vname' => 'LBL_SOEL_CAMPUS',
    'type' => 'varchar',
    'source' => 'non-db',
    
);