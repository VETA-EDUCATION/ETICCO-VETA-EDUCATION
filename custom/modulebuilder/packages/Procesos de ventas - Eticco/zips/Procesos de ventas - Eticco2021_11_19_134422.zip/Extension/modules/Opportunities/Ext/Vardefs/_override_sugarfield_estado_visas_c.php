<?php
 // created: 2019-12-05 07:34:08
$dictionary['Opportunity']['fields']['estado_visas_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_visas_c']['labelValue']='Estado Visas';

 ?>