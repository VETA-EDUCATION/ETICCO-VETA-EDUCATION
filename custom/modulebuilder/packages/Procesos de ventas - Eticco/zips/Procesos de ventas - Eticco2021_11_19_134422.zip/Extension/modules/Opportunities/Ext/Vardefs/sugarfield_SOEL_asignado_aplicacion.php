<?php
$dictionary['Opportunity']['fields']['soel_asignado_aplicacion'] = array(
    'name' => 'soel_asignado_aplicacion',
    'vname' => 'LBL_SOEL_ASIGNADO_APLICACION',
    'type' => 'enum',
    'source' => 'non-db',
    'function' => 'getAsignadoLeads',
    'massupdate' => false,
);
