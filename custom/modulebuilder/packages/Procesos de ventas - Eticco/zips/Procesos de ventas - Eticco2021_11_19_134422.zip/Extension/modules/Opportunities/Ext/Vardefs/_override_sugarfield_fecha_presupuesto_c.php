<?php
 // created: 2020-03-16 13:06:55
$dictionary['Opportunity']['fields']['fecha_presupuesto_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_presupuesto_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_presupuesto_c']['labelValue']='Fecha del Presupuesto';
$dictionary['Opportunity']['fields']['fecha_presupuesto_c']['enable_range_search']='1';

 ?>