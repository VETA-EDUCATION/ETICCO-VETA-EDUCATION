<?php
 // created: 2019-12-11 13:04:59
$dictionary['Opportunity']['fields']['recibo_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['recibo_c']['labelValue']='Recibo';

 ?>