<?php
 // created: 2019-12-07 15:56:54
$dictionary['Opportunity']['fields']['estado_pago_institucion_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_pago_institucion_c']['labelValue']='Estado Pago Institución';

 ?>