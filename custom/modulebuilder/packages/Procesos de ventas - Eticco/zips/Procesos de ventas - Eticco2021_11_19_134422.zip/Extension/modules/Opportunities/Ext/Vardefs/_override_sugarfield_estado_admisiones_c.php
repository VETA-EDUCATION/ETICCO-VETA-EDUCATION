<?php
 // created: 2020-01-26 13:14:12
$dictionary['Opportunity']['fields']['estado_admisiones_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_admisiones_c']['labelValue']='Estado Admisiones';

 ?>