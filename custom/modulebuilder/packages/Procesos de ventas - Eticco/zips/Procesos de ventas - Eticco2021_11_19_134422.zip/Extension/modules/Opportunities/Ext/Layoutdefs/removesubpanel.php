<?php

//SOEL
unset($layout_defs['Opportunities']['subpanel_setup']['contacts']);
unset($layout_defs['Opportunities']['subpanel_setup']['leads']);
unset($layout_defs['Opportunities']['subpanel_setup']['documents']);
unset($layout_defs['Opportunities']['subpanel_setup']['veta_pagocolegios_opportunities']);


?>