<?php
 // created: 2020-01-23 15:00:52
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_c']['labelValue']='Fecha Ultimo Contacto';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_c']['enable_range_search']='1';

 ?>