<?php
 // created: 2019-11-02 17:02:02
$dictionary['Opportunity']['fields']['fecha_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_c']['labelValue']='Fecha';

 ?>