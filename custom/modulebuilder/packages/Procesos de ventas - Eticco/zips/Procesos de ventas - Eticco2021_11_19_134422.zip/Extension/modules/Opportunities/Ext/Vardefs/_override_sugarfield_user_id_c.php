<?php
 // created: 2020-03-16 15:28:07
$dictionary['Opportunity']['fields']['user_id_c']['inline_edit']=1;

 ?>