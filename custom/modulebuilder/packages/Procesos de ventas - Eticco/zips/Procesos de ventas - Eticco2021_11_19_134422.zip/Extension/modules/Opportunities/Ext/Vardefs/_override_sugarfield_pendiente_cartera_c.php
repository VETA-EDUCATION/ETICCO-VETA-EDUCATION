<?php
 // created: 2019-12-05 07:55:24
$dictionary['Opportunity']['fields']['pendiente_cartera_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['pendiente_cartera_c']['labelValue']='Pendiente Cartera';

 ?>