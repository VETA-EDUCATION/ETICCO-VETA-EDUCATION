<?php
$mod_strings['LBL_SOEL_CAMPUS'] = 'Campus';


