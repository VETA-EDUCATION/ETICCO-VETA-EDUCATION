<?php
$dictionary['Opportunity']['fields']['soel_asignado_visas'] = array(
    'name' => 'soel_asignado_visas',
    'vname' => 'LBL_SOEL_ASIGNADO_VISAS',
    'type' => 'enum',
    'source' => 'non-db',
    'function' => 'getAsignadoLeads',
    'massupdate' => false,
);
