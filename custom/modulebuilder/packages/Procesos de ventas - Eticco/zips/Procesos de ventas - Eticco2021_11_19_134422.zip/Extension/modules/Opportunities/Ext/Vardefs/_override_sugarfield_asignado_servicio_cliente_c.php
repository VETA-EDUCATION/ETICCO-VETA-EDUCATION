<?php
 // created: 2020-03-16 15:31:03
$dictionary['Opportunity']['fields']['asignado_servicio_cliente_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['asignado_servicio_cliente_c']['labelValue']='Asignado Servicio al Cliente';

 ?>