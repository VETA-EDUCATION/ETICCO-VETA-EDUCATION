<?php
 // created: 2019-12-27 14:03:26
$dictionary['Opportunity']['fields']['description']['audited']=true;
$dictionary['Opportunity']['fields']['description']['inline_edit']='';
$dictionary['Opportunity']['fields']['description']['comments']='Full text of the note';
$dictionary['Opportunity']['fields']['description']['merge_filter']='disabled';

 ?>