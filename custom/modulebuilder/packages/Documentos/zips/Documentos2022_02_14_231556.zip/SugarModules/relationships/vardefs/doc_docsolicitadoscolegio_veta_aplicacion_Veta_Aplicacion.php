<?php
// created: 2022-02-14 23:15:55
$dictionary["Veta_Aplicacion"]["fields"]["doc_docsolicitadoscolegio_veta_aplicacion"] = array (
  'name' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'type' => 'link',
  'relationship' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'source' => 'non-db',
  'module' => 'Doc_DocSolicitadosColegio',
  'bean_name' => false,
  'vname' => 'LBL_DOC_DOCSOLICITADOSCOLEGIO_VETA_APLICACION_FROM_DOC_DOCSOLICITADOSCOLEGIO_TITLE',
  'id_name' => 'doc_docsol30e6colegio_ida',
);
$dictionary["Veta_Aplicacion"]["fields"]["doc_docsolicitadoscolegio_veta_aplicacion_name"] = array (
  'name' => 'doc_docsolicitadoscolegio_veta_aplicacion_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_DOC_DOCSOLICITADOSCOLEGIO_VETA_APLICACION_FROM_DOC_DOCSOLICITADOSCOLEGIO_TITLE',
  'save' => true,
  'id_name' => 'doc_docsol30e6colegio_ida',
  'link' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'table' => 'doc_docsolicitadoscolegio',
  'module' => 'Doc_DocSolicitadosColegio',
  'rname' => 'name',
);
$dictionary["Veta_Aplicacion"]["fields"]["doc_docsol30e6colegio_ida"] = array (
  'name' => 'doc_docsol30e6colegio_ida',
  'type' => 'link',
  'relationship' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_DOC_DOCSOLICITADOSCOLEGIO_VETA_APLICACION_FROM_VETA_APLICACION_TITLE',
);
