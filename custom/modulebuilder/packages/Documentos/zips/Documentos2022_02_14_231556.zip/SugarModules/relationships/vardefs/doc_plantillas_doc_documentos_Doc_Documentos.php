<?php
// created: 2022-02-14 23:15:55
$dictionary["Doc_Documentos"]["fields"]["doc_plantillas_doc_documentos"] = array (
  'name' => 'doc_plantillas_doc_documentos',
  'type' => 'link',
  'relationship' => 'doc_plantillas_doc_documentos',
  'source' => 'non-db',
  'module' => 'Doc_Plantillas',
  'bean_name' => 'Doc_Plantillas',
  'vname' => 'LBL_DOC_PLANTILLAS_DOC_DOCUMENTOS_FROM_DOC_PLANTILLAS_TITLE',
);
