<?php
// created: 2022-02-14 23:15:55
$dictionary["Opportunity"]["fields"]["doc_comentarios_opportunities"] = array (
  'name' => 'doc_comentarios_opportunities',
  'type' => 'link',
  'relationship' => 'doc_comentarios_opportunities',
  'source' => 'non-db',
  'module' => 'Doc_Comentarios',
  'bean_name' => 'Doc_Comentarios',
  'side' => 'right',
  'vname' => 'LBL_DOC_COMENTARIOS_OPPORTUNITIES_FROM_DOC_COMENTARIOS_TITLE',
);
