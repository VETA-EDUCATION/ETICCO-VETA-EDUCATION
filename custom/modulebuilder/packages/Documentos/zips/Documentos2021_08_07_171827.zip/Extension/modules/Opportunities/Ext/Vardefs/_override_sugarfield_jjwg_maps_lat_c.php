<?php
 // created: 2019-10-09 10:48:06
$dictionary['Opportunity']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>