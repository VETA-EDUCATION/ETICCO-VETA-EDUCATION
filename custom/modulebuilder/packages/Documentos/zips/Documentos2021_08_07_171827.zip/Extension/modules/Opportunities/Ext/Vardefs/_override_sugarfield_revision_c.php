<?php
 // created: 2019-11-02 17:09:15
$dictionary['Opportunity']['fields']['revision_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['revision_c']['labelValue']='Revisión';

 ?>