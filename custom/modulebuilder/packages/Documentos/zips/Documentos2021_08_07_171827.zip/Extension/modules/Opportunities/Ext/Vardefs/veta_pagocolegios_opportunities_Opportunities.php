<?php
// created: 2020-10-14 00:58:31
$dictionary["Opportunity"]["fields"]["veta_pagocolegios_opportunities"] = array (
  'name' => 'veta_pagocolegios_opportunities',
  'type' => 'link',
  'relationship' => 'veta_pagocolegios_opportunities',
  'source' => 'non-db',
  'module' => 'Veta_PagoColegios',
  'bean_name' => 'Veta_PagoColegios',
  'side' => 'right',
  'vname' => 'LBL_VETA_PAGOCOLEGIOS_OPPORTUNITIES_FROM_VETA_PAGOCOLEGIOS_TITLE',
);
