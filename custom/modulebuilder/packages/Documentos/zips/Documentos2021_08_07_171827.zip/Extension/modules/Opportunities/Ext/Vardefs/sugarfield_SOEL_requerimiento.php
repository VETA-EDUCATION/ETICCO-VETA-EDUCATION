<?php
$dictionary['Opportunity']['fields']['soel_requerimiento'] = array(
    'name' => 'soel_requerimiento',
    'vname' => 'LBL_SOEL_REQUERIMIENTO',
    'type' => 'varchar',
    'source' => 'non-db',
);
