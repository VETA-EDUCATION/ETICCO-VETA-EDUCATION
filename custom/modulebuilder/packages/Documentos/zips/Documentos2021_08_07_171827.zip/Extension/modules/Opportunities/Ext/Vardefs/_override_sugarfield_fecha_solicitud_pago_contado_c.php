<?php
 // created: 2019-11-02 17:05:05
$dictionary['Opportunity']['fields']['fecha_solicitud_pago_contado_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_solicitud_pago_contado_c']['labelValue']='Fecha de Solicitud de Pago al Contador';

 ?>