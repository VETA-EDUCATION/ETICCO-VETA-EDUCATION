<?php
 // created: 2019-11-02 17:10:03
$dictionary['Opportunity']['fields']['saldo_pendiente_pago_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['saldo_pendiente_pago_c']['labelValue']='Saldo Pendiente de Pago';

 ?>