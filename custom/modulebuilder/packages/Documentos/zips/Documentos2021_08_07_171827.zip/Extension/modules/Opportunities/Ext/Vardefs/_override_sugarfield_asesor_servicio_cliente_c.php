<?php
 // created: 2019-12-11 18:49:09
$dictionary['Opportunity']['fields']['asesor_servicio_cliente_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['asesor_servicio_cliente_c']['labelValue']='Asesor Servicio al Cliente';
$dictionary['Opportunity']['fields']['asesor_servicio_cliente_c']['massupdate']=true;

 ?>