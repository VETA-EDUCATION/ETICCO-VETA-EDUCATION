<?php
 // created: 2019-11-02 17:07:51
$dictionary['Opportunity']['fields']['monto_dolares_australianos_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['monto_dolares_australianos_c']['labelValue']='Monto Dolares Australianos';

 ?>