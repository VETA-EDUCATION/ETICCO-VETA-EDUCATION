<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['doc_comentarios_opportunities']['override_subpanel_name'] = 'Opportunity_subpanel_doc_comentarios_opportunities';
?>