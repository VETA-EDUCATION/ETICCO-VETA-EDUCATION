<?php
 // created: 2019-12-05 07:55:52
$dictionary['Opportunity']['fields']['pendiente_pago_colegios_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['pendiente_pago_colegios_c']['labelValue']='Pendiente Pago Colegios';

 ?>