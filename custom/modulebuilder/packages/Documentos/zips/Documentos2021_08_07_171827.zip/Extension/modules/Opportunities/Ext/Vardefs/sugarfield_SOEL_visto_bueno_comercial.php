<?php
$dictionary['Opportunity']['fields']['soel_visto_bueno_comercial'] = array(
    'name' => 'soel_visto_bueno_comercial',
    'vname' => 'LBL_SOEL_VISTO_BUENO_COMERCIAL',
    'type' => 'bool',
    'source' => 'non-db',
    'default' => '0',
    'no_default' => false,
);