<?php
 // created: 2019-12-07 15:45:37
$dictionary['Opportunity']['fields']['sales_stage']['default']='Progreso';
$dictionary['Opportunity']['fields']['sales_stage']['options']='sales_stage_list';

 ?>