<?php
 // created: 2019-11-02 17:03:35
$dictionary['Opportunity']['fields']['fecha_firma_contrato_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_firma_contrato_c']['labelValue']='Fecha Firma Contrato';

 ?>