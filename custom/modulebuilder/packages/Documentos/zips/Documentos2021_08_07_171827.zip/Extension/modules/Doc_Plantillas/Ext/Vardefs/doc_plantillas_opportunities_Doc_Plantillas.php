<?php
// created: 2021-08-03 19:41:26
$dictionary["Doc_Plantillas"]["fields"]["doc_plantillas_opportunities"] = array (
  'name' => 'doc_plantillas_opportunities',
  'type' => 'link',
  'relationship' => 'doc_plantillas_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_DOC_PLANTILLAS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
