<?php
 // created: 2019-12-05 07:25:03
$dictionary['Opportunity']['fields']['estado_gestion_comercial_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_gestion_comercial_c']['labelValue']='Estado Gestion Comercial';

 ?>