<?php
 // created: 2019-11-02 16:58:17
$dictionary['Opportunity']['fields']['fecha_apertura_cuenta_bancar_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_apertura_cuenta_bancar_c']['labelValue']='Fecha Apertura Cuenta Bancaria';

 ?>