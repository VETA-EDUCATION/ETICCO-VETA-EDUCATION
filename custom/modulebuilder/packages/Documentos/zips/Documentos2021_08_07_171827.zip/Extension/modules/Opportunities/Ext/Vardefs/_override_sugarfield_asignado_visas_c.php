<?php
 // created: 2020-03-16 15:28:43
$dictionary['Opportunity']['fields']['asignado_visas_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['asignado_visas_c']['labelValue']='Asignado Visas';

 ?>