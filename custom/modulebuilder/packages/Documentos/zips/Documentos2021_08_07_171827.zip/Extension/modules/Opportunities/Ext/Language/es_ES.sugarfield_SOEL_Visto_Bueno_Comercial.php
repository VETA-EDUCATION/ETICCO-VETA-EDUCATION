<?php
$mod_strings['LBL_SOEL_VISTO_BUENO_COMERCIAL'] = 'Visto Bueno Comercial';
