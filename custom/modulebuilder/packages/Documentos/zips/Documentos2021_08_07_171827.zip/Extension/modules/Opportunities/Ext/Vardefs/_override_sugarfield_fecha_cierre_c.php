<?php
 // created: 2021-06-16 21:30:50
$dictionary['Opportunity']['fields']['fecha_cierre_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_cierre_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_cierre_c']['labelValue']='Fecha de Cierre';
$dictionary['Opportunity']['fields']['fecha_cierre_c']['enable_range_search']='1';

 ?>