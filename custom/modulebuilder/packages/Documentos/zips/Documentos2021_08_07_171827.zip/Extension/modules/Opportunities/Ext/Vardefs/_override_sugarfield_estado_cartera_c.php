<?php
 // created: 2019-12-04 09:55:26
$dictionary['Opportunity']['fields']['estado_cartera_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['estado_cartera_c']['labelValue']='Estado Cartera';

 ?>