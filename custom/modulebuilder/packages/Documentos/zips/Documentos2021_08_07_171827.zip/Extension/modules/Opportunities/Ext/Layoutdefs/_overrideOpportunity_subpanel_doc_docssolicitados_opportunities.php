<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['doc_docssolicitados_opportunities']['override_subpanel_name'] = 'Opportunity_subpanel_doc_docssolicitados_opportunities';
?>