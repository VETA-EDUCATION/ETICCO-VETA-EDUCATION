<?php
 // created: 2020-01-23 15:02:34
$dictionary['Opportunity']['fields']['fecha_expiracion_visa_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_expiracion_visa_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_expiracion_visa_c']['labelValue']='Fecha Expiracion Visa';
$dictionary['Opportunity']['fields']['fecha_expiracion_visa_c']['enable_range_search']='1';

 ?>