<?php
 // created: 2019-12-11 13:04:59
$dictionary['Opportunity']['fields']['veta_recibo_id_c']['inline_edit']=1;

 ?>