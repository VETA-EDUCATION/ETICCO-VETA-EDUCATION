<?php
 // created: 2020-03-16 15:31:02
$dictionary['Opportunity']['fields']['user_id2_c']['inline_edit']=1;

 ?>