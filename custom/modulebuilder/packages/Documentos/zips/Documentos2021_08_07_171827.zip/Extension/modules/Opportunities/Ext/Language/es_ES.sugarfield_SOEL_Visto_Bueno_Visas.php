<?php
$mod_strings['LBL_SOEL_VISTO_BUENO_VISAS'] = 'Visto Bueno Visas';
$mod_strings['LBL_SOEL_DOCS_PENDIENTES'] = 'Docs Pendientes';
$mod_strings['LBL_SOEL_DOCS_SOLICITADOS'] = 'Docs Solicitados';
$mod_strings['LBL_SOEL_DOCS_CARGADOS'] = 'Docs Cargados';
$mod_strings['LBL_SOEL_DATE_ESTUDIANTE'] = 'Act Estudiante';
$mod_strings['LBL_SOEL_DATE_ASESOR'] = 'Act Asesor';

