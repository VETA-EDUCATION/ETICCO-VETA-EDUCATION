<?php
 // created: 2020-01-23 15:01:25
$dictionary['Opportunity']['fields']['fecha_proximo_contacto_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_proximo_contacto_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_proximo_contacto_c']['labelValue']='Fecha Proximo Contacto';
$dictionary['Opportunity']['fields']['fecha_proximo_contacto_c']['enable_range_search']='1';

 ?>