<?php
 // created: 2020-01-23 13:01:04
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_new_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_new_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_new_c']['labelValue']='Fecha Ultimo Contacto.';
$dictionary['Opportunity']['fields']['fecha_ultimo_contacto_new_c']['enable_range_search']='1';

 ?>