<?php
 // created: 2021-05-11 13:51:03
$dictionary['Opportunity']['fields']['fecha_aplicacion_visa_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['fecha_aplicacion_visa_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['fecha_aplicacion_visa_c']['labelValue']='Visa Application Date';
$dictionary['Opportunity']['fields']['fecha_aplicacion_visa_c']['enable_range_search']='1';

 ?>