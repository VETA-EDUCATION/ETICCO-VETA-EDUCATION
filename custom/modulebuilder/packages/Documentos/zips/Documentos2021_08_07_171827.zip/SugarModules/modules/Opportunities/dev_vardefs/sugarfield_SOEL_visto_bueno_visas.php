<?php
$dictionary['Opportunity']['fields']['soel_visto_bueno_visas'] = array(
    'name' => 'soel_visto_bueno_visas',
    'vname' => 'LBL_SOEL_VISTO_BUENO_VISAS',
    'type' => 'bool',
    'source' => 'non-db',
    'default' => '0',
    'no_default' => false,
);