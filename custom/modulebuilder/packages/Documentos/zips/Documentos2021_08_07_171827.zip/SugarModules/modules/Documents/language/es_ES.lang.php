<?php 
 // created: 2021-08-07 17:18:24
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Procesos de Venta';

?>
