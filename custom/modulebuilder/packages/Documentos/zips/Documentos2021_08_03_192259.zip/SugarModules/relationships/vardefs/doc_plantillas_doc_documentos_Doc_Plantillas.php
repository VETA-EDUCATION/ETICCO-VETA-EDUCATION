<?php
// created: 2021-08-03 19:22:59
$dictionary["Doc_Plantillas"]["fields"]["doc_plantillas_doc_documentos"] = array (
  'name' => 'doc_plantillas_doc_documentos',
  'type' => 'link',
  'relationship' => 'doc_plantillas_doc_documentos',
  'source' => 'non-db',
  'module' => 'Doc_Documentos',
  'bean_name' => 'Doc_Documentos',
  'vname' => 'LBL_DOC_PLANTILLAS_DOC_DOCUMENTOS_FROM_DOC_DOCUMENTOS_TITLE',
);
