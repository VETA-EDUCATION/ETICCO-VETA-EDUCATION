<?php
// created: 2022-02-14 23:15:13
$dictionary["Doc_DocSolicitadosColegio"]["fields"]["doc_docsolicitadoscolegio_veta_aplicacion"] = array (
  'name' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'type' => 'link',
  'relationship' => 'doc_docsolicitadoscolegio_veta_aplicacion',
  'source' => 'non-db',
  'module' => 'Veta_Aplicacion',
  'bean_name' => 'Veta_Aplicacion',
  'side' => 'right',
  'vname' => 'LBL_DOC_DOCSOLICITADOSCOLEGIO_VETA_APLICACION_FROM_VETA_APLICACION_TITLE',
);
