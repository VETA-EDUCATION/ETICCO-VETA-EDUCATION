<?php
// created: 2022-02-14 23:15:13
$dictionary["Opportunity"]["fields"]["doc_documentos_adic_opportunities"] = array (
  'name' => 'doc_documentos_adic_opportunities',
  'type' => 'link',
  'relationship' => 'doc_documentos_adic_opportunities',
  'source' => 'non-db',
  'module' => 'Doc_Documentos_Adic',
  'bean_name' => 'Doc_Documentos_Adic',
  'vname' => 'LBL_DOC_DOCUMENTOS_ADIC_OPPORTUNITIES_FROM_DOC_DOCUMENTOS_ADIC_TITLE',
);
