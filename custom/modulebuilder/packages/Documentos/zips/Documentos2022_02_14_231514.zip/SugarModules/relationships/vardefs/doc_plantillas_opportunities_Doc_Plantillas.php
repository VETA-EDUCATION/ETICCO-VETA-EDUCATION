<?php
// created: 2022-02-14 23:15:13
$dictionary["Doc_Plantillas"]["fields"]["doc_plantillas_opportunities"] = array (
  'name' => 'doc_plantillas_opportunities',
  'type' => 'link',
  'relationship' => 'doc_plantillas_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_DOC_PLANTILLAS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
