<?php
// created: 2022-02-14 22:37:46
$dictionary["Opportunity"]["fields"]["doc_plantillas_opportunities"] = array (
  'name' => 'doc_plantillas_opportunities',
  'type' => 'link',
  'relationship' => 'doc_plantillas_opportunities',
  'source' => 'non-db',
  'module' => 'Doc_Plantillas',
  'bean_name' => 'Doc_Plantillas',
  'vname' => 'LBL_DOC_PLANTILLAS_OPPORTUNITIES_FROM_DOC_PLANTILLAS_TITLE',
);
