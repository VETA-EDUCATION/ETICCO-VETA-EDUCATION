<?php 
 // created: 2021-08-04 22:14:49
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Procesos de Venta';

?>
