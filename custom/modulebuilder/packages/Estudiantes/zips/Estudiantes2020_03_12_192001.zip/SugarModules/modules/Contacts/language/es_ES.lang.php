<?php 
 // created: 2020-03-12 19:19:44
$mod_strings['LBL_PRESUPUESTO'] = 'Presupuesto';
$mod_strings['LBL_FECHA_VIAJE'] = 'Fecha de Viaje';
$mod_strings['LBL_CARRERA_UNIVERSITARIA'] = 'Carrera Universitaria';
$mod_strings['LBL_TRABAJO_ACTUAL'] = 'Trabajo Actual';
$mod_strings['LBL_DIRECCION'] = 'Direccion.';
$mod_strings['LBL_CASES_SUBPANEL_TITLE'] = 'Casos';
$mod_strings['LBL_CONTACTS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Proceso de Venta';
$mod_strings['LBL_OPPORTUNITIES'] = 'Procesos de Venta';
$mod_strings['LBL_OPPORTUNITY_ROLE'] = 'Rol en Proceso de Venta';
$mod_strings['LBL_OPPORTUNITY_ROLE_ID'] = 'ID de Rol en Proceso de Venta';
$mod_strings['LBL_DESCRIPTION'] = 'Observaciones';
$mod_strings['LBL_SOEL_AUDITORIA'] = 'OBS';
$mod_strings['LBL_FECHA_EXPIRACION_VISA'] = 'Fecha Expiracion Visa';
$mod_strings['LBL_NACIMIENTO_CONYUGE'] = 'Fecha Nacimiento Conyuge';
$mod_strings['LBL_FECHA_ULTIMO_CONTACTO'] = 'Fecha Ultimo Contacto';
$mod_strings['LBL_FECHA_PROXIMO_CONTACTO'] = 'Fecha Proximo Contacto';
$mod_strings['LBL_VETA_RECIBO_CONTACTS_FROM_VETA_RECIBO_TITLE'] = 'Cuentas de Cobro';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Prospectos';
$mod_strings['LBL_VETA_PASAPORTE_CONTACTS_FROM_VETA_PASAPORTE_TITLE'] = 'Pasaportes';
$mod_strings['LBL_VETA_INFORMACIONLABORAL_CONTACTS_FROM_VETA_INFORMACIONLABORAL_TITLE'] = 'Información Laboral';
$mod_strings['LBL_VETA_OTROSNOMBRES_CONTACTS_FROM_VETA_OTROSNOMBRES_TITLE'] = 'Otros Nombres';
$mod_strings['LBL_VETA_CIUDADANIA_CONTACTS_FROM_VETA_CIUDADANIA_TITLE'] = 'Ciudadania';
$mod_strings['LBL_VETA_INFORMACIONACADEMICA_CONTACTS_FROM_VETA_INFORMACIONACADEMICA_TITLE'] = 'Información Academica';
$mod_strings['LBL_VETA_VISAS_CONTACTS_FROM_VETA_VISAS_TITLE'] = 'Visas';
$mod_strings['LBL_VETA_SOLVENCIAECONOMICA_CONTACTS_FROM_VETA_SOLVENCIAECONOMICA_TITLE'] = 'Solvencia Economica';
$mod_strings['LBL_VETA_SERVICIOSADICIONALES_CONTACTS_FROM_VETA_SERVICIOSADICIONALES_TITLE'] = 'Servicios Adicionales';

?>
