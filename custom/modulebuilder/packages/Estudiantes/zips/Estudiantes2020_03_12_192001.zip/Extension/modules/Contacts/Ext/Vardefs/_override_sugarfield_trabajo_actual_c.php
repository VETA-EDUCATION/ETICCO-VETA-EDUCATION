<?php
 // created: 2019-10-29 20:19:08
$dictionary['Contact']['fields']['trabajo_actual_c']['inline_edit']='';
$dictionary['Contact']['fields']['trabajo_actual_c']['labelValue']='Trabajo Actual';

 ?>