<?php
 // created: 2018-02-17 09:47:04
$dictionary['Contact']['fields']['identificacion_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['identificacion_australia_c']['labelValue']='Identificacion Australia';

 ?>