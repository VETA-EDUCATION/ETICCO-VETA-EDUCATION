<?php
 // created: 2018-02-17 09:45:47
$dictionary['Contact']['fields']['estado_civil_c']['inline_edit']='';
$dictionary['Contact']['fields']['estado_civil_c']['labelValue']='Estado Civil';

 ?>