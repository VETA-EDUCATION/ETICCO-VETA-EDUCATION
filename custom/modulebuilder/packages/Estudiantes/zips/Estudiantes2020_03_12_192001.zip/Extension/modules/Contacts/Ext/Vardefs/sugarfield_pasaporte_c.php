<?php
 // created: 2018-02-17 09:53:00
$dictionary['Contact']['fields']['pasaporte_c']['inline_edit']='';
$dictionary['Contact']['fields']['pasaporte_c']['labelValue']='Pasaporte';

 ?>