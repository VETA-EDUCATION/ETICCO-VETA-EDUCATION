<?php
 // created: 2018-02-17 16:56:27
$dictionary['Contact']['fields']['birthdate']['inline_edit']='';
$dictionary['Contact']['fields']['birthdate']['comments']='The birthdate of the contact';
$dictionary['Contact']['fields']['birthdate']['merge_filter']='disabled';
$dictionary['Contact']['fields']['birthdate']['enable_range_search']=false;

 ?>