<?php
$dictionary['Contact']['fields']['soel_auditoria'] = array(
    'name' => 'soel_auditoria',
    'vname' => 'LBL_SOEL_AUDITORIA',
    'type' => 'varchar',
    'source' => 'non-db',
);