<?php
 // created: 2019-10-09 14:59:07
$dictionary['Contact']['fields']['identificacion_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['identificacion_australia_c']['labelValue']='Identificacion Australia';

 ?>