<?php
 // created: 2018-02-17 16:56:58
$dictionary['Contact']['fields']['email1']['inline_edit']='';
$dictionary['Contact']['fields']['email1']['merge_filter']='disabled';

 ?>