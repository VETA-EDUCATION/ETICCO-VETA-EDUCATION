<?php
 // created: 2019-10-09 14:59:06
$dictionary['Contact']['fields']['cuenta_bancaria_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['cuenta_bancaria_australia_c']['labelValue']='Cuenta Bancaria Australia';

 ?>