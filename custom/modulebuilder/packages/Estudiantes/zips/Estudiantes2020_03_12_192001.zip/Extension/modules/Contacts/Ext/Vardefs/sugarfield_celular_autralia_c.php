<?php
 // created: 2018-02-17 09:32:25
$dictionary['Contact']['fields']['celular_autralia_c']['inline_edit']='';
$dictionary['Contact']['fields']['celular_autralia_c']['labelValue']='Número Celular Australia';

 ?>