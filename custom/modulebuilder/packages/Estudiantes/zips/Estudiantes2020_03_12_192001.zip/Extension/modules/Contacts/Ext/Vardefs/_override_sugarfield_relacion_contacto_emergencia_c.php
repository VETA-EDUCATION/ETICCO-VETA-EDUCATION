<?php
 // created: 2019-10-09 14:59:08
$dictionary['Contact']['fields']['relacion_contacto_emergencia_c']['inline_edit']='';
$dictionary['Contact']['fields']['relacion_contacto_emergencia_c']['labelValue']='Relación Contacto Emergencia';

 ?>