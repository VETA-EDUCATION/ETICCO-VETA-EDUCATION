<?php
 // created: 2018-02-17 16:59:23
$dictionary['Contact']['fields']['first_name']['inline_edit']='';
$dictionary['Contact']['fields']['first_name']['comments']='First name of the contact';
$dictionary['Contact']['fields']['first_name']['merge_filter']='disabled';

 ?>