<?php
 // created: 2018-02-17 09:40:13
$dictionary['Contact']['fields']['ciudad_nacimiento_c']['inline_edit']='';
$dictionary['Contact']['fields']['ciudad_nacimiento_c']['labelValue']='Ciudad de Nacimiento';

 ?>