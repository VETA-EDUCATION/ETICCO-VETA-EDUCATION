<?php
 // created: 2018-02-17 09:39:21
$dictionary['Contact']['fields']['departamento_nacimiento_c']['inline_edit']='';
$dictionary['Contact']['fields']['departamento_nacimiento_c']['labelValue']='Departamento de Nacimiento';

 ?>