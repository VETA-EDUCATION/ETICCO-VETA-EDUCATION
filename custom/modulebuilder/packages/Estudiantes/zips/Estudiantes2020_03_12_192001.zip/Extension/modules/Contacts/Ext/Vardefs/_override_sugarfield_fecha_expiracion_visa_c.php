<?php
 // created: 2020-01-23 14:49:57
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['labelValue']='Fecha Expiracion Visa';
$dictionary['Contact']['fields']['fecha_expiracion_visa_c']['enable_range_search']='1';

 ?>