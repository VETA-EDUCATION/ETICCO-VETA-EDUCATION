<?php
 // created: 2018-02-17 17:00:05
$dictionary['Contact']['fields']['title']['inline_edit']='';
$dictionary['Contact']['fields']['title']['comments']='The title of the contact';
$dictionary['Contact']['fields']['title']['merge_filter']='disabled';

 ?>