<?php
 // created: 2018-02-17 09:55:08
$dictionary['Contact']['fields']['visa_negada_c']['inline_edit']='';
$dictionary['Contact']['fields']['visa_negada_c']['labelValue']='Visa Negada ?';

 ?>