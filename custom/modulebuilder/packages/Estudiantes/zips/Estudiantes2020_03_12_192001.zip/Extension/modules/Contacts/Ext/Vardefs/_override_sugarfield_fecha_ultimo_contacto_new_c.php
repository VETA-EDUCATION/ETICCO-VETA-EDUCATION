<?php
 // created: 2020-01-23 12:57:43
$dictionary['Contact']['fields']['fecha_ultimo_contacto_new_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_new_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_new_c']['labelValue']='Fecha Ultimo Contacto.';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_new_c']['enable_range_search']='1';

 ?>