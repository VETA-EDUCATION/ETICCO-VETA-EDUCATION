<?php
 // created: 2020-01-23 14:51:33
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['labelValue']='Fecha Nacimiento Conyuge';
$dictionary['Contact']['fields']['nacimiento_conyuge_c']['enable_range_search']='1';

 ?>