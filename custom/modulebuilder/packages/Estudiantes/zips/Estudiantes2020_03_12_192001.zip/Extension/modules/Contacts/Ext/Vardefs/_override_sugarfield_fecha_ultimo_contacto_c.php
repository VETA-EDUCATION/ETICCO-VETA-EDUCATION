<?php
 // created: 2020-01-23 14:53:46
$dictionary['Contact']['fields']['fecha_ultimo_contacto_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_c']['labelValue']='Fecha Ultimo Contacto';
$dictionary['Contact']['fields']['fecha_ultimo_contacto_c']['enable_range_search']='1';

 ?>