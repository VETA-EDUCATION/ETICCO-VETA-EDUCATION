<?php
 // created: 2018-02-17 09:46:32
$dictionary['Contact']['fields']['genero_c']['inline_edit']='';
$dictionary['Contact']['fields']['genero_c']['labelValue']='Genero';

 ?>