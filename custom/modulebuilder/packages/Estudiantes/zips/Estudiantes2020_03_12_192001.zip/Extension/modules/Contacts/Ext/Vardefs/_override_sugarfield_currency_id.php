<?php
 // created: 2019-10-29 19:59:13
$dictionary['Contact']['fields']['currency_id']['inline_edit']=1;

 ?>