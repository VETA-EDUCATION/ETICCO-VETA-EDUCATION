<?php
 // created: 2019-12-27 14:00:31
$dictionary['Contact']['fields']['description']['inline_edit']='';
$dictionary['Contact']['fields']['description']['comments']='Full text of the note';
$dictionary['Contact']['fields']['description']['merge_filter']='disabled';
$dictionary['Contact']['fields']['description']['audited']=true;

 ?>