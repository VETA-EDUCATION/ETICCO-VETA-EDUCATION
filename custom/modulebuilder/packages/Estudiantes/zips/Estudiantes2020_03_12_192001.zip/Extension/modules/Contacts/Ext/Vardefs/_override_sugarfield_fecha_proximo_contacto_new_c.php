<?php
 // created: 2020-01-23 12:58:37
$dictionary['Contact']['fields']['fecha_proximo_contacto_new_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_proximo_contacto_new_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_proximo_contacto_new_c']['labelValue']='Fecha Proximo Contacto.';
$dictionary['Contact']['fields']['fecha_proximo_contacto_new_c']['enable_range_search']='1';

 ?>