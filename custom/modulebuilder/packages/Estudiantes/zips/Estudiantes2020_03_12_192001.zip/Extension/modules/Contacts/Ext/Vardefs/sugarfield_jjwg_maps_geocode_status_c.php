<?php
 // created: 2018-02-16 14:47:34
$dictionary['Contact']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>