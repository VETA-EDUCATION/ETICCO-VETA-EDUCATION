<?php
 // created: 2019-10-09 14:59:06
$dictionary['Contact']['fields']['edad_c']['inline_edit']='';
$dictionary['Contact']['fields']['edad_c']['options']='numeric_range_search_dom';
$dictionary['Contact']['fields']['edad_c']['labelValue']='Edad';
$dictionary['Contact']['fields']['edad_c']['enable_range_search']='1';

 ?>