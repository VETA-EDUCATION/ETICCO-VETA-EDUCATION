<?php
 // created: 2019-10-09 14:59:07
$dictionary['Contact']['fields']['edad_conyuge_c']['inline_edit']='';
$dictionary['Contact']['fields']['edad_conyuge_c']['labelValue']='Edad Conyuge';

 ?>