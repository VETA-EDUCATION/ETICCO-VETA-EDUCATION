<?php
 // created: 2019-10-29 20:15:44
$dictionary['Contact']['fields']['fecha_viaje_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_viaje_c']['labelValue']='Fecha de Viaje';

 ?>