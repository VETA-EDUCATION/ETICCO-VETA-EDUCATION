<?php
// created: 2020-01-24 09:34:10
$dictionary["Contact"]["fields"]["veta_serviciosadicionales_contacts"] = array (
  'name' => 'veta_serviciosadicionales_contacts',
  'type' => 'link',
  'relationship' => 'veta_serviciosadicionales_contacts',
  'source' => 'non-db',
  'module' => 'Veta_ServiciosAdicionales',
  'bean_name' => 'Veta_ServiciosAdicionales',
  'side' => 'right',
  'vname' => 'LBL_VETA_SERVICIOSADICIONALES_CONTACTS_FROM_VETA_SERVICIOSADICIONALES_TITLE',
);
