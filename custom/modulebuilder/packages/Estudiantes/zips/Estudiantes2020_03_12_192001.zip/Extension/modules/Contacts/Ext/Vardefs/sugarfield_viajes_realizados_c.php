<?php
 // created: 2018-02-17 09:54:37
$dictionary['Contact']['fields']['viajes_realizados_c']['inline_edit']='';
$dictionary['Contact']['fields']['viajes_realizados_c']['labelValue']='Viajes Realizados';

 ?>