<?php
 // created: 2019-10-09 14:59:07
$dictionary['Contact']['fields']['institucion_australia_c']['inline_edit']='';
$dictionary['Contact']['fields']['institucion_australia_c']['labelValue']='Institucion Australia';

 ?>