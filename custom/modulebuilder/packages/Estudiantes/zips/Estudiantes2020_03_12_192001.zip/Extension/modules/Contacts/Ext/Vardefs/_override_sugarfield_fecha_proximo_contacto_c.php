<?php
 // created: 2020-01-23 14:54:56
$dictionary['Contact']['fields']['fecha_proximo_contacto_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_proximo_contacto_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_proximo_contacto_c']['labelValue']='Fecha Proximo Contacto';
$dictionary['Contact']['fields']['fecha_proximo_contacto_c']['enable_range_search']='1';

 ?>