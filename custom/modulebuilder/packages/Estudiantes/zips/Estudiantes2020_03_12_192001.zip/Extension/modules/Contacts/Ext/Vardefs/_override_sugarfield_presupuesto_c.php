<?php
 // created: 2019-10-29 19:59:13
$dictionary['Contact']['fields']['presupuesto_c']['inline_edit']='';
$dictionary['Contact']['fields']['presupuesto_c']['labelValue']='Presupuesto';

 ?>