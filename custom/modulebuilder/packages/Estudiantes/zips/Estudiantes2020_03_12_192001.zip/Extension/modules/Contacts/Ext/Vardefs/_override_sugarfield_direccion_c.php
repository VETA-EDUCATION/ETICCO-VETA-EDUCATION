<?php
 // created: 2019-10-29 21:56:45
$dictionary['Contact']['fields']['direccion_c']['inline_edit']='';
$dictionary['Contact']['fields']['direccion_c']['labelValue']='Direccion.';

 ?>