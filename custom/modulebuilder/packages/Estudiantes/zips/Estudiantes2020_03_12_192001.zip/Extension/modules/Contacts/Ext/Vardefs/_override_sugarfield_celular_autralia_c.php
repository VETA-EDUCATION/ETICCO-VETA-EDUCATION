<?php
 // created: 2019-10-09 14:59:05
$dictionary['Contact']['fields']['celular_autralia_c']['inline_edit']='';
$dictionary['Contact']['fields']['celular_autralia_c']['labelValue']='Número Celular Australia';

 ?>