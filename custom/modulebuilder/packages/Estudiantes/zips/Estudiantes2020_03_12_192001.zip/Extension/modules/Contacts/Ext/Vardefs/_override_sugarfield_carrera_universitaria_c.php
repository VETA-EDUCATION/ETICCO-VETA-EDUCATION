<?php
 // created: 2019-10-29 20:18:18
$dictionary['Contact']['fields']['carrera_universitaria_c']['inline_edit']='';
$dictionary['Contact']['fields']['carrera_universitaria_c']['labelValue']='Carrera Universitaria';

 ?>