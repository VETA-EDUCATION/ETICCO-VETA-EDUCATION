<?php

// SOEL
unset($layout_defs['Contacts']['subpanel_setup']['opportunities']);
unset($layout_defs['Contacts']['subpanel_setup']['contacts']);
unset($layout_defs['Contacts']['subpanel_setup']['documents']);

?>