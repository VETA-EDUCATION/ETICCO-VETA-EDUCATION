<?php
 // created: 2019-10-09 14:59:07
$dictionary['Contact']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>