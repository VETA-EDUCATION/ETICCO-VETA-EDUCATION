<?php
 // created: 2018-02-17 09:38:29
$dictionary['Contact']['fields']['pais_nacimiento_c']['inline_edit']='';
$dictionary['Contact']['fields']['pais_nacimiento_c']['labelValue']='Pais de Nacimiento';

 ?>