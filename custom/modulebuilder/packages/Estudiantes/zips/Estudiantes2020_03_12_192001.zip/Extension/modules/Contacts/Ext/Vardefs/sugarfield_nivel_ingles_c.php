<?php
 // created: 2018-02-17 09:49:31
$dictionary['Contact']['fields']['nivel_ingles_c']['inline_edit']='';
$dictionary['Contact']['fields']['nivel_ingles_c']['labelValue']='Nivel de Ingles';

 ?>