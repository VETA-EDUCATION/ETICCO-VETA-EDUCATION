<?php
 // created: 2018-02-17 09:40:43
$dictionary['Contact']['fields']['contacto_emergencia_c']['inline_edit']='';
$dictionary['Contact']['fields']['contacto_emergencia_c']['labelValue']='Contacto Emergencia';

 ?>