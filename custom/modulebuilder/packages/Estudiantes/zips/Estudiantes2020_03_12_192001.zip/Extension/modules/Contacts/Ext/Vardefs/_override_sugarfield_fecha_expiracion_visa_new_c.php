<?php
 // created: 2020-01-23 09:23:30
$dictionary['Contact']['fields']['fecha_expiracion_visa_new_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_expiracion_visa_new_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_expiracion_visa_new_c']['labelValue']='Fecha Expiración Visa.';
$dictionary['Contact']['fields']['fecha_expiracion_visa_new_c']['enable_range_search']='1';

 ?>