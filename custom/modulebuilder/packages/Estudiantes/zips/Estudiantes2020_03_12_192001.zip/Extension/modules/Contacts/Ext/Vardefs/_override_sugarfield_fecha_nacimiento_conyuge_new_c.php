<?php
 // created: 2020-01-23 12:56:58
$dictionary['Contact']['fields']['fecha_nacimiento_conyuge_new_c']['inline_edit']='';
$dictionary['Contact']['fields']['fecha_nacimiento_conyuge_new_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['fecha_nacimiento_conyuge_new_c']['labelValue']='Fecha Nacimiento Conyuge.';
$dictionary['Contact']['fields']['fecha_nacimiento_conyuge_new_c']['enable_range_search']='1';

 ?>