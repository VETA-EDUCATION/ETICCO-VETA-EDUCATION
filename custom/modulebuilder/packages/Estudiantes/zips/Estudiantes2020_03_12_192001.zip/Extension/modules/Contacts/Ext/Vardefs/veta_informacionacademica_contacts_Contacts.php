<?php
// created: 2020-01-24 09:34:02
$dictionary["Contact"]["fields"]["veta_informacionacademica_contacts"] = array (
  'name' => 'veta_informacionacademica_contacts',
  'type' => 'link',
  'relationship' => 'veta_informacionacademica_contacts',
  'source' => 'non-db',
  'module' => 'Veta_InformacionAcademica',
  'bean_name' => 'Veta_InformacionAcademica',
  'side' => 'right',
  'vname' => 'LBL_VETA_INFORMACIONACADEMICA_CONTACTS_FROM_VETA_INFORMACIONACADEMICA_TITLE',
);
