<?php
 // created: 2018-02-17 09:42:10
$dictionary['Contact']['fields']['direccion_c']['inline_edit']='';
$dictionary['Contact']['fields']['direccion_c']['labelValue']='Direccion';

 ?>