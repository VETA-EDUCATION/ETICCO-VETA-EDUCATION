<?php
 // created: 2019-10-09 14:59:06
$dictionary['Contact']['fields']['departamento_nacimiento_c']['inline_edit']='';
$dictionary['Contact']['fields']['departamento_nacimiento_c']['labelValue']='Departamento de Nacimiento';

 ?>