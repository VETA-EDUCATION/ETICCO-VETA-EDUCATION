<?php
 // created: 2019-10-09 14:59:08
$dictionary['Contact']['fields']['pasaporte_c']['inline_edit']='';
$dictionary['Contact']['fields']['pasaporte_c']['labelValue']='Pasaporte';

 ?>